"""
Coverage Analyzer Module
========================

Measures and analyzes code coverage using Coverage.py.
"""

import subprocess
import sys
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Set


@dataclass
class FileCoverage:
    """Coverage information for a single file."""
    filename: str
    covered_lines: List[int]
    missing_lines: List[int]
    excluded_lines: List[int]
    num_statements: int
    num_missing: int
    num_branches: int = 0
    num_partial_branches: int = 0
    coverage_percent: float = 0.0


@dataclass
class CoverageReport:
    """Complete coverage report."""
    total_statements: int
    total_missing: int
    total_covered: int
    coverage_percent: float
    files: List[FileCoverage]
    uncovered_lines: Dict[str, List[int]] = field(default_factory=dict)


class CoverageAnalyzer:
    """
    Analyzes code coverage using Coverage.py.
    
    Features:
    - Run tests with coverage measurement
    - Generate detailed coverage reports
    - Identify uncovered lines and branches
    - Support for multiple coverage formats
    """
    
    def __init__(self, working_dir: Optional[str] = None):
        self.working_dir = Path(working_dir) if working_dir else Path.cwd()
        self._coverage_data_file = self.working_dir / ".coverage"
        self._coverage_json_file = self.working_dir / "coverage.json"
    
    def run_with_coverage(
        self,
        test_path: str,
        source_path: str,
        branch: bool = True
    ) -> CoverageReport:
        """
        Run tests and collect coverage data.
        
        Args:
            test_path: Path to test file or directory
            source_path: Path to source file or directory to measure
            branch: Whether to measure branch coverage
        
        Returns:
            CoverageReport with detailed coverage information
        """
        source_path = Path(source_path)
        test_path = Path(test_path)
        
        # Build coverage command
        cmd = [
            sys.executable, "-m", "coverage", "run",
            "--source", str(source_path.parent if source_path.is_file() else source_path),
        ]
        
        if branch:
            cmd.append("--branch")
        
        # Add pytest command
        cmd.extend(["-m", "pytest", str(test_path), "-v"])
        
        # Run tests with coverage
        result = subprocess.run(
            cmd,
            cwd=str(self.working_dir),
            capture_output=True,
            text=True,
            timeout=300
        )
        
        # Generate JSON report
        self._generate_json_report()
        
        # Parse and return coverage report
        return self._parse_coverage_report(source_path)
    
    def _generate_json_report(self):
        """Generate a JSON coverage report."""
        cmd = [
            sys.executable, "-m", "coverage", "json",
            "-o", str(self._coverage_json_file)
        ]
        
        subprocess.run(
            cmd,
            cwd=str(self.working_dir),
            capture_output=True,
            text=True
        )
    
    def _parse_coverage_report(self, source_path: Path) -> CoverageReport:
        """Parse the JSON coverage report."""
        if not self._coverage_json_file.exists():
            return CoverageReport(
                total_statements=0,
                total_missing=0,
                total_covered=0,
                coverage_percent=0.0,
                files=[]
            )
        
        with open(self._coverage_json_file, 'r') as f:
            data = json.load(f)
        
        files = []
        uncovered_lines = {}
        
        for filename, file_data in data.get("files", {}).items():
            summary = file_data.get("summary", {})
            
            covered = file_data.get("executed_lines", [])
            missing = file_data.get("missing_lines", [])
            excluded = file_data.get("excluded_lines", [])
            
            num_statements = summary.get("num_statements", 0)
            num_missing = summary.get("missing_lines", len(missing))
            coverage_pct = summary.get("percent_covered", 0.0)
            
            file_cov = FileCoverage(
                filename=filename,
                covered_lines=covered,
                missing_lines=missing,
                excluded_lines=excluded,
                num_statements=num_statements,
                num_missing=num_missing,
                num_branches=summary.get("num_branches", 0),
                num_partial_branches=summary.get("num_partial_branches", 0),
                coverage_percent=coverage_pct
            )
            
            files.append(file_cov)
            
            if missing:
                uncovered_lines[filename] = missing
        
        # Calculate totals
        totals = data.get("totals", {})
        
        return CoverageReport(
            total_statements=totals.get("num_statements", 0),
            total_missing=totals.get("missing_lines", 0),
            total_covered=totals.get("covered_lines", 0),
            coverage_percent=totals.get("percent_covered", 0.0),
            files=files,
            uncovered_lines=uncovered_lines
        )
    
    def get_coverage_summary(self) -> Dict[str, Any]:
        """Get a quick coverage summary from existing data."""
        cmd = [
            sys.executable, "-m", "coverage", "report", "--format=total"
        ]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=str(self.working_dir),
                capture_output=True,
                text=True
            )
            
            # Parse percentage from output
            try:
                percent = float(result.stdout.strip())
            except ValueError:
                percent = 0.0
            
            return {
                "coverage_percent": percent,
                "raw_output": result.stdout
            }
        
        except Exception as e:
            return {
                "coverage_percent": 0.0,
                "error": str(e)
            }
    
    def get_detailed_report(self) -> str:
        """Get a detailed terminal coverage report."""
        cmd = [
            sys.executable, "-m", "coverage", "report",
            "--show-missing"
        ]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=str(self.working_dir),
                capture_output=True,
                text=True
            )
            return result.stdout
        except Exception as e:
            return f"Error generating report: {e}"
    
    def get_uncovered_lines(self, source_file: str) -> List[int]:
        """
        Get list of uncovered lines for a specific source file.
        
        Args:
            source_file: Path to source file
        
        Returns:
            List of uncovered line numbers
        """
        if not self._coverage_json_file.exists():
            return []
        
        with open(self._coverage_json_file, 'r') as f:
            data = json.load(f)
        
        source_path = Path(source_file)
        
        for filename, file_data in data.get("files", {}).items():
            if source_path.name in filename or filename in str(source_path):
                return file_data.get("missing_lines", [])
        
        return []
    
    def meets_coverage_threshold(self, threshold: float = 90.0) -> bool:
        """
        Check if coverage meets the specified threshold.
        
        Args:
            threshold: Minimum coverage percentage required
        
        Returns:
            True if coverage meets or exceeds threshold
        """
        summary = self.get_coverage_summary()
        return summary.get("coverage_percent", 0.0) >= threshold
    
    def generate_html_report(self, output_dir: str = "htmlcov") -> str:
        """
        Generate an HTML coverage report.
        
        Args:
            output_dir: Directory for HTML output
        
        Returns:
            Path to the generated report
        """
        output_path = self.working_dir / output_dir
        
        cmd = [
            sys.executable, "-m", "coverage", "html",
            "-d", str(output_path)
        ]
        
        subprocess.run(
            cmd,
            cwd=str(self.working_dir),
            capture_output=True,
            text=True
        )
        
        return str(output_path / "index.html")
    
    def cleanup(self):
        """Remove coverage data files."""
        if self._coverage_data_file.exists():
            self._coverage_data_file.unlink()
        if self._coverage_json_file.exists():
            self._coverage_json_file.unlink()

