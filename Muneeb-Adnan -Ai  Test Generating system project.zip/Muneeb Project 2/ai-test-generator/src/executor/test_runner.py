"""
Test Runner Module
==================

Executes PyTest tests and collects results.
"""

import subprocess
import sys
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum


class TestStatus(Enum):
    """Test execution status."""
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"
    SKIPPED = "skipped"
    XFAIL = "xfail"
    XPASS = "xpass"


@dataclass
class TestResult:
    """Result of a single test."""
    name: str
    status: TestStatus
    duration: float
    error_message: Optional[str] = None
    traceback: Optional[str] = None


@dataclass
class TestRunSummary:
    """Summary of a test run."""
    total: int
    passed: int
    failed: int
    errors: int
    skipped: int
    duration: float
    exit_code: int
    results: List[TestResult] = field(default_factory=list)


class TestRunner:
    """
    Runs PyTest tests and collects results.
    
    Features:
    - Execute tests with coverage measurement
    - Collect detailed test results
    - Support for test selection and filtering
    """
    
    def __init__(self, working_dir: Optional[str] = None):
        self.working_dir = Path(working_dir) if working_dir else Path.cwd()
        self.pytest_args: List[str] = []
    
    def run_tests(
        self,
        test_path: str,
        source_path: Optional[str] = None,
        with_coverage: bool = True,
        verbose: bool = True,
        timeout: int = 300
    ) -> TestRunSummary:
        """
        Run pytest on the specified test file or directory.
        
        Args:
            test_path: Path to test file or directory
            source_path: Path to source file for coverage measurement
            with_coverage: Whether to measure coverage
            verbose: Whether to use verbose output
            timeout: Maximum time for test execution in seconds
        
        Returns:
            TestRunSummary with results
        """
        test_path = Path(test_path)
        if not test_path.exists():
            raise FileNotFoundError(f"Test path not found: {test_path}")
        
        # Build pytest command
        cmd = [sys.executable, "-m", "pytest", str(test_path)]
        
        if verbose:
            cmd.append("-v")
        
        # Add JSON report for parsing
        cmd.extend(["--tb=short"])
        
        # Add coverage if requested
        if with_coverage and source_path:
            source_path = Path(source_path)
            cmd.extend([
                f"--cov={source_path.parent}",
                f"--cov-report=json",
                "--cov-report=term"
            ])
        
        # Add timeout
        cmd.extend([f"--timeout={timeout}"])
        
        # Add custom args
        cmd.extend(self.pytest_args)
        
        # Run pytest
        try:
            result = subprocess.run(
                cmd,
                cwd=str(self.working_dir),
                capture_output=True,
                text=True,
                timeout=timeout + 30
            )
            
            return self._parse_output(result)
        
        except subprocess.TimeoutExpired:
            return TestRunSummary(
                total=0,
                passed=0,
                failed=0,
                errors=1,
                skipped=0,
                duration=timeout,
                exit_code=-1,
                results=[TestResult(
                    name="timeout",
                    status=TestStatus.ERROR,
                    duration=timeout,
                    error_message=f"Test execution timed out after {timeout} seconds"
                )]
            )
        except Exception as e:
            return TestRunSummary(
                total=0,
                passed=0,
                failed=1,
                errors=1,
                skipped=0,
                duration=0,
                exit_code=-1,
                results=[TestResult(
                    name="error",
                    status=TestStatus.ERROR,
                    duration=0,
                    error_message=str(e)
                )]
            )
    
    def _parse_output(self, result: subprocess.CompletedProcess) -> TestRunSummary:
        """Parse pytest output to extract test results."""
        output = result.stdout + result.stderr
        
        # Parse test counts from output
        passed = 0
        failed = 0
        errors = 0
        skipped = 0
        
        # Look for summary line like "5 passed, 2 failed, 1 skipped"
        import re
        
        # Match patterns like "5 passed"
        passed_match = re.search(r'(\d+)\s+passed', output)
        failed_match = re.search(r'(\d+)\s+failed', output)
        error_match = re.search(r'(\d+)\s+error', output)
        skipped_match = re.search(r'(\d+)\s+skipped', output)
        
        if passed_match:
            passed = int(passed_match.group(1))
        if failed_match:
            failed = int(failed_match.group(1))
        if error_match:
            errors = int(error_match.group(1))
        if skipped_match:
            skipped = int(skipped_match.group(1))
        
        total = passed + failed + errors + skipped
        
        # Parse duration
        duration = 0.0
        duration_match = re.search(r'in\s+([\d.]+)s', output)
        if duration_match:
            duration = float(duration_match.group(1))
        
        # Parse individual test results
        results = self._parse_individual_results(output)
        
        return TestRunSummary(
            total=total,
            passed=passed,
            failed=failed,
            errors=errors,
            skipped=skipped,
            duration=duration,
            exit_code=result.returncode,
            results=results
        )
    
    def _parse_individual_results(self, output: str) -> List[TestResult]:
        """Parse individual test results from pytest output."""
        results = []
        import re
        
        # Match lines like "test_file.py::test_function PASSED"
        # or "test_file.py::TestClass::test_method FAILED"
        pattern = r'([\w/\\]+\.py::[:\w]+)\s+(PASSED|FAILED|ERROR|SKIPPED)'
        
        for match in re.finditer(pattern, output):
            name = match.group(1)
            status_str = match.group(2)
            
            status_map = {
                'PASSED': TestStatus.PASSED,
                'FAILED': TestStatus.FAILED,
                'ERROR': TestStatus.ERROR,
                'SKIPPED': TestStatus.SKIPPED
            }
            
            results.append(TestResult(
                name=name,
                status=status_map.get(status_str, TestStatus.ERROR),
                duration=0.0  # Individual durations not easily parsed
            ))
        
        return results
    
    def run_specific_tests(
        self,
        test_path: str,
        test_names: List[str],
        source_path: Optional[str] = None,
        with_coverage: bool = True
    ) -> TestRunSummary:
        """
        Run specific test functions by name.
        
        Args:
            test_path: Path to test file
            test_names: List of test function names to run
            source_path: Path to source for coverage
            with_coverage: Whether to measure coverage
        
        Returns:
            TestRunSummary with results
        """
        # Build test selection expression
        if test_names:
            self.pytest_args = ["-k", " or ".join(test_names)]
        
        result = self.run_tests(
            test_path=test_path,
            source_path=source_path,
            with_coverage=with_coverage
        )
        
        # Reset args
        self.pytest_args = []
        
        return result
    
    def validate_test_syntax(self, test_file: str) -> Dict[str, Any]:
        """
        Validate that a test file has valid Python syntax.
        
        Args:
            test_file: Path to test file to validate
        
        Returns:
            Dictionary with validation results
        """
        test_path = Path(test_file)
        
        if not test_path.exists():
            return {
                "valid": False,
                "error": f"File not found: {test_file}"
            }
        
        try:
            # Try to compile the file
            source = test_path.read_text(encoding='utf-8')
            compile(source, str(test_path), 'exec')
            
            return {
                "valid": True,
                "file": str(test_path)
            }
        
        except SyntaxError as e:
            return {
                "valid": False,
                "error": str(e),
                "line": e.lineno,
                "offset": e.offset
            }
        except Exception as e:
            return {
                "valid": False,
                "error": str(e)
            }
    
    def collect_tests(self, test_path: str) -> List[str]:
        """
        Collect test names without running them.
        
        Args:
            test_path: Path to test file or directory
        
        Returns:
            List of test names
        """
        cmd = [
            sys.executable, "-m", "pytest",
            str(test_path),
            "--collect-only", "-q"
        ]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=str(self.working_dir),
                capture_output=True,
                text=True,
                timeout=60
            )
            
            tests = []
            for line in result.stdout.splitlines():
                line = line.strip()
                if line and '::' in line and not line.startswith('<'):
                    tests.append(line)
            
            return tests
        
        except Exception:
            return []

