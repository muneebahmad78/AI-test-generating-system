"""
AI-Powered Automated Test Generator for Python
===============================================

A comprehensive system that uses static code analysis and LLM-based reasoning
to automatically generate high-quality PyTest unit tests.
"""

__version__ = "1.0.0"
__author__ = "AI Test Generator"

