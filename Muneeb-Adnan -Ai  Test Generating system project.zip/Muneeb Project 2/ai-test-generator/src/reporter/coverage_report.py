"""
Coverage Reporter Module
========================

Displays clear and formatted coverage reports in the terminal.
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.syntax import Syntax
    from rich.text import Text
    from rich import box
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from ..executor.coverage_analyzer import CoverageReport, FileCoverage


class CoverageReporter:
    """
    Generates beautiful terminal coverage reports.
    
    Uses Rich library for enhanced formatting when available,
    falls back to basic text output otherwise.
    """
    
    def __init__(self):
        if RICH_AVAILABLE:
            self.console = Console()
        else:
            self.console = None
    
    def display_summary(
        self,
        report: CoverageReport,
        target_coverage: float = 90.0
    ):
        """Display a coverage summary."""
        if RICH_AVAILABLE:
            self._display_rich_summary(report, target_coverage)
        else:
            self._display_basic_summary(report, target_coverage)
    
    def _display_rich_summary(
        self,
        report: CoverageReport,
        target_coverage: float
    ):
        """Display summary using Rich formatting."""
        # Determine status color
        if report.coverage_percent >= target_coverage:
            status_color = "green"
            status_text = "✓ PASSED"
        elif report.coverage_percent >= target_coverage * 0.8:
            status_color = "yellow"
            status_text = "⚠ NEEDS IMPROVEMENT"
        else:
            status_color = "red"
            status_text = "✗ FAILED"
        
        # Create summary panel
        summary_text = Text()
        summary_text.append(f"\n  Coverage: ", style="bold")
        summary_text.append(f"{report.coverage_percent:.1f}%", style=f"bold {status_color}")
        summary_text.append(f"  (Target: {target_coverage}%)\n\n")
        summary_text.append(f"  Statements: {report.total_statements}\n")
        summary_text.append(f"  Covered:    {report.total_covered}\n")
        summary_text.append(f"  Missing:    {report.total_missing}\n")
        
        panel = Panel(
            summary_text,
            title=f"[bold {status_color}]{status_text}[/bold {status_color}]",
            title_align="center",
            border_style=status_color,
            box=box.ROUNDED
        )
        
        self.console.print()
        self.console.print(panel)
    
    def _display_basic_summary(
        self,
        report: CoverageReport,
        target_coverage: float
    ):
        """Display summary using basic text formatting."""
        passed = report.coverage_percent >= target_coverage
        status = "PASSED" if passed else "FAILED"
        
        print()
        print("=" * 60)
        print(f"  COVERAGE REPORT - {status}")
        print("=" * 60)
        print(f"  Coverage: {report.coverage_percent:.1f}% (Target: {target_coverage}%)")
        print(f"  Statements: {report.total_statements}")
        print(f"  Covered: {report.total_covered}")
        print(f"  Missing: {report.total_missing}")
        print("=" * 60)
        print()
    
    def display_file_details(self, report: CoverageReport):
        """Display detailed coverage for each file."""
        if RICH_AVAILABLE:
            self._display_rich_file_details(report)
        else:
            self._display_basic_file_details(report)
    
    def _display_rich_file_details(self, report: CoverageReport):
        """Display file details using Rich table."""
        table = Table(
            title="File Coverage Details",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan"
        )
        
        table.add_column("File", style="dim")
        table.add_column("Statements", justify="right")
        table.add_column("Missing", justify="right")
        table.add_column("Coverage", justify="right")
        table.add_column("Status", justify="center")
        
        for file_cov in report.files:
            # Determine color based on coverage
            if file_cov.coverage_percent >= 90:
                color = "green"
                status = "✓"
            elif file_cov.coverage_percent >= 70:
                color = "yellow"
                status = "⚠"
            else:
                color = "red"
                status = "✗"
            
            # Shorten filename for display
            filename = file_cov.filename
            if len(filename) > 40:
                filename = "..." + filename[-37:]
            
            table.add_row(
                filename,
                str(file_cov.num_statements),
                str(file_cov.num_missing),
                f"[{color}]{file_cov.coverage_percent:.1f}%[/{color}]",
                f"[{color}]{status}[/{color}]"
            )
        
        self.console.print()
        self.console.print(table)
    
    def _display_basic_file_details(self, report: CoverageReport):
        """Display file details using basic text."""
        print("\nFile Coverage Details:")
        print("-" * 70)
        print(f"{'File':<40} {'Stmts':>8} {'Miss':>8} {'Cover':>10}")
        print("-" * 70)
        
        for file_cov in report.files:
            filename = file_cov.filename
            if len(filename) > 38:
                filename = "..." + filename[-35:]
            
            print(f"{filename:<40} {file_cov.num_statements:>8} "
                  f"{file_cov.num_missing:>8} {file_cov.coverage_percent:>9.1f}%")
        
        print("-" * 70)
    
    def display_uncovered_lines(
        self,
        report: CoverageReport,
        source_code: Optional[Dict[str, str]] = None
    ):
        """Display uncovered lines with context."""
        if not report.uncovered_lines:
            if RICH_AVAILABLE:
                self.console.print("[green]All lines covered![/green]")
            else:
                print("All lines covered!")
            return
        
        if RICH_AVAILABLE:
            self._display_rich_uncovered_lines(report, source_code)
        else:
            self._display_basic_uncovered_lines(report)
    
    def _display_rich_uncovered_lines(
        self,
        report: CoverageReport,
        source_code: Optional[Dict[str, str]]
    ):
        """Display uncovered lines using Rich formatting."""
        self.console.print("\n[bold red]Uncovered Lines:[/bold red]")
        
        for filename, lines in report.uncovered_lines.items():
            if not lines:
                continue
            
            # Group consecutive lines
            line_ranges = self._group_consecutive_lines(lines)
            range_str = ", ".join(line_ranges)
            
            self.console.print(f"\n  [cyan]{filename}[/cyan]")
            self.console.print(f"    Lines: [yellow]{range_str}[/yellow]")
            
            # Show source code context if available
            if source_code and filename in source_code:
                self._show_source_context(filename, lines[:5], source_code[filename])
    
    def _display_basic_uncovered_lines(self, report: CoverageReport):
        """Display uncovered lines using basic text."""
        print("\nUncovered Lines:")
        print("-" * 50)
        
        for filename, lines in report.uncovered_lines.items():
            if not lines:
                continue
            
            line_ranges = self._group_consecutive_lines(lines)
            range_str = ", ".join(line_ranges)
            
            print(f"\n  {filename}")
            print(f"    Lines: {range_str}")
    
    def _group_consecutive_lines(self, lines: List[int]) -> List[str]:
        """Group consecutive line numbers into ranges."""
        if not lines:
            return []
        
        lines = sorted(lines)
        ranges = []
        start = lines[0]
        end = lines[0]
        
        for line in lines[1:]:
            if line == end + 1:
                end = line
            else:
                if start == end:
                    ranges.append(str(start))
                else:
                    ranges.append(f"{start}-{end}")
                start = end = line
        
        # Add last range
        if start == end:
            ranges.append(str(start))
        else:
            ranges.append(f"{start}-{end}")
        
        return ranges
    
    def _show_source_context(
        self,
        filename: str,
        lines: List[int],
        source: str
    ):
        """Show source code context for uncovered lines."""
        source_lines = source.splitlines()
        
        for line_num in lines[:3]:  # Show max 3 uncovered lines
            if 1 <= line_num <= len(source_lines):
                line_content = source_lines[line_num - 1]
                syntax = Syntax(
                    line_content,
                    "python",
                    line_numbers=True,
                    start_line=line_num,
                    highlight_lines={line_num}
                )
                self.console.print(f"      ", end="")
                self.console.print(syntax)
    
    def display_test_generation_progress(self, message: str):
        """Display a progress message during test generation."""
        if RICH_AVAILABLE:
            self.console.print(f"[bold blue]⚡[/bold blue] {message}")
        else:
            print(f">>> {message}")
    
    def display_success(self, message: str):
        """Display a success message."""
        if RICH_AVAILABLE:
            self.console.print(f"[bold green]✓[/bold green] {message}")
        else:
            print(f"[SUCCESS] {message}")
    
    def display_warning(self, message: str):
        """Display a warning message."""
        if RICH_AVAILABLE:
            self.console.print(f"[bold yellow]⚠[/bold yellow] {message}")
        else:
            print(f"[WARNING] {message}")
    
    def display_error(self, message: str):
        """Display an error message."""
        if RICH_AVAILABLE:
            self.console.print(f"[bold red]✗[/bold red] {message}")
        else:
            print(f"[ERROR] {message}")
    
    def display_info(self, message: str):
        """Display an info message."""
        if RICH_AVAILABLE:
            self.console.print(f"[bold cyan]ℹ[/bold cyan] {message}")
        else:
            print(f"[INFO] {message}")
    
    def display_test_results(
        self,
        passed: int,
        failed: int,
        errors: int,
        skipped: int,
        duration: float
    ):
        """Display test execution results."""
        total = passed + failed + errors + skipped
        
        if RICH_AVAILABLE:
            self.console.print()
            
            result_text = Text()
            result_text.append("Test Results: ")
            
            if passed > 0:
                result_text.append(f"{passed} passed", style="green")
            if failed > 0:
                result_text.append(f", {failed} failed", style="red")
            if errors > 0:
                result_text.append(f", {errors} errors", style="red")
            if skipped > 0:
                result_text.append(f", {skipped} skipped", style="yellow")
            
            result_text.append(f" in {duration:.2f}s")
            
            self.console.print(result_text)
        else:
            print()
            print(f"Test Results: {passed} passed, {failed} failed, "
                  f"{errors} errors, {skipped} skipped in {duration:.2f}s")
    
    def display_regeneration_notice(
        self,
        current_coverage: float,
        target_coverage: float
    ):
        """Display a notice about test regeneration."""
        gap = target_coverage - current_coverage
        
        if RICH_AVAILABLE:
            self.console.print()
            self.console.print(Panel(
                f"[yellow]Coverage is {current_coverage:.1f}%, which is {gap:.1f}% below the target of {target_coverage}%.\n"
                f"Regenerating additional tests to improve coverage...[/yellow]",
                title="[bold yellow]Coverage Below Target[/bold yellow]",
                border_style="yellow"
            ))
        else:
            print()
            print("=" * 60)
            print("  COVERAGE BELOW TARGET")
            print(f"  Current: {current_coverage:.1f}%  Target: {target_coverage}%")
            print("  Regenerating additional tests...")
            print("=" * 60)

