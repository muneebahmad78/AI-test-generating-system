"""
Reporting Module
================

Coverage reporting and result visualization.
"""

from .coverage_report import CoverageReporter

__all__ = ["CoverageReporter"]

