"""
Test Generator Module
=====================

Generates high-quality PyTest unit tests using LLM-based reasoning.
"""

from typing import List, Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass
import re
import json

from ..analyzer.code_parser import TestableUnit, CodeParser
from .llm_client import LLMClient, LLMProvider
from .edge_cases import EdgeCaseDetector, EdgeCase


@dataclass
class GeneratedTest:
    """Represents a generated test."""
    function_name: str
    test_code: str
    target_function: str
    edge_cases_covered: List[str]
    estimated_coverage: float


# System prompt for test generation
SYSTEM_PROMPT = """You are an expert Python test engineer specializing in writing comprehensive PyTest unit tests.

Your task is to generate high-quality test cases that:
1. Follow PyTest best practices and conventions
2. Use descriptive test function names (test_<function>_<scenario>)
3. Include docstrings explaining what each test verifies
4. Cover normal cases, edge cases, and error scenarios
5. Use appropriate assertions (assert, pytest.raises, etc.)
6. Are self-contained and don't depend on external state
7. Use fixtures where appropriate for setup/teardown
8. Include parametrized tests for similar test cases

Output ONLY valid Python code. Do not include markdown code fences or explanations.
The code should be directly executable as a pytest test file."""


class TestGenerator:
    """
    Generates unit tests using LLM-based reasoning.
    
    Combines static code analysis with AI to produce
    comprehensive test suites.
    """
    
    def __init__(
        self,
        llm_provider: Optional[LLMProvider] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None
    ):
        self.llm_client = LLMClient(
            provider=llm_provider,
            model=model,
            api_key=api_key
        )
        self.edge_case_detector = EdgeCaseDetector()
    
    def generate_tests(
        self,
        source_file: str,
        output_dir: str = "tests",
        min_coverage: float = 90.0
    ) -> Dict[str, Any]:
        """
        Generate tests for a Python source file.
        
        Args:
            source_file: Path to the Python source file
            output_dir: Directory to save generated tests
            min_coverage: Target minimum coverage percentage
        
        Returns:
            Dictionary with generation results
        """
        source_path = Path(source_file)
        if not source_path.exists():
            raise FileNotFoundError(f"Source file not found: {source_file}")
        
        # Parse the source code
        source_code = source_path.read_text(encoding='utf-8')
        parser = CodeParser(source_code, str(source_path))
        parser.parse()
        
        # Get testable units
        testable_units = parser.get_testable_units()
        
        if not testable_units:
            return {
                "success": False,
                "message": "No testable units found in the source file",
                "tests_generated": 0
            }
        
        # Generate tests for each unit
        generated_tests = []
        for unit in testable_units:
            test = self._generate_test_for_unit(unit, source_path.stem)
            if test:
                generated_tests.append(test)
        
        # Combine into test file
        test_file_content = self._create_test_file(
            generated_tests,
            source_path.stem,
            parser.get_import_context()
        )
        
        # Save test file
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        test_file_path = output_path / f"test_{source_path.stem}.py"
        test_file_path.write_text(test_file_content, encoding='utf-8')
        
        return {
            "success": True,
            "test_file": str(test_file_path),
            "tests_generated": len(generated_tests),
            "testable_units": len(testable_units),
            "provider": self.llm_client.provider_name
        }
    
    def _generate_test_for_unit(
        self,
        unit: TestableUnit,
        module_name: str
    ) -> Optional[GeneratedTest]:
        """Generate tests for a single testable unit."""
        # Detect edge cases
        edge_cases = self.edge_case_detector.detect_edge_cases(
            parameters=unit.parameters,
            return_type=unit.return_type,
            raises=unit.raises,
            source_code=unit.source_code
        )
        
        # Build the prompt
        prompt = self._build_test_prompt(unit, edge_cases, module_name)
        
        # Generate tests using LLM
        try:
            response = self.llm_client.generate(prompt, SYSTEM_PROMPT)
            test_code = self._clean_generated_code(response.content)
            
            return GeneratedTest(
                function_name=unit.name,
                test_code=test_code,
                target_function=unit.qualified_name,
                edge_cases_covered=[ec.description for ec in edge_cases[:5]],
                estimated_coverage=85.0  # Estimate, actual measured later
            )
        except Exception as e:
            print(f"Warning: Failed to generate tests for {unit.name}: {e}")
            return None
    
    def _build_test_prompt(
        self,
        unit: TestableUnit,
        edge_cases: List[EdgeCase],
        module_name: str
    ) -> str:
        """Build the prompt for test generation."""
        edge_case_descriptions = "\n".join(
            f"- {ec.description}: expect {ec.expected_behavior}"
            for ec in edge_cases[:10]  # Limit to top 10
        )
        
        prompt = f"""Generate comprehensive PyTest unit tests for the following Python {unit.type}:

## Source Code
```python
{unit.source_code}
```

## Function Signature
{unit.signature}

## Function Details
- Name: {unit.qualified_name}
- Parameters: {json.dumps(unit.parameters, indent=2)}
- Return Type: {unit.return_type or 'Not specified'}
- Complexity: {unit.complexity}
- Raises: {', '.join(unit.raises) if unit.raises else 'None specified'}

## Docstring
{unit.docstring or 'No docstring provided'}

## Edge Cases to Cover
{edge_case_descriptions}

## Branch Coverage Requirements
The function has {len(unit.branches)} branches:
{json.dumps(unit.branches, indent=2)}

## Requirements
1. Import the function from the module: `from {module_name} import {unit.name}`
2. Write tests that achieve high branch coverage
3. Include tests for all edge cases listed above
4. Use pytest.raises for exception testing
5. Use pytest.mark.parametrize for similar test cases
6. Each test function should have a clear docstring

Generate the test code:"""
        
        return prompt
    
    def _clean_generated_code(self, code: str) -> str:
        """Clean up generated code by removing markdown formatting."""
        # Remove markdown code fences
        code = re.sub(r'^```python\s*\n', '', code)
        code = re.sub(r'^```\s*\n', '', code)
        code = re.sub(r'\n```\s*$', '', code)
        code = re.sub(r'^```\s*', '', code)
        
        # Ensure proper line endings
        code = code.strip()
        
        return code
    
    def _create_test_file(
        self,
        generated_tests: List[GeneratedTest],
        module_name: str,
        import_context: str
    ) -> str:
        """Create a complete test file from generated tests."""
        header = f'''"""
Auto-Generated Unit Tests for {module_name}
============================================

Generated by AI Test Generator
Target: {module_name}.py

This test file covers:
{chr(10).join(f"- {t.target_function}" for t in generated_tests)}
"""

import pytest
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from {module_name} import *


'''
        
        # Combine all test code
        test_bodies = []
        for test in generated_tests:
            test_bodies.append(f"# Tests for {test.target_function}")
            test_bodies.append(test.test_code)
            test_bodies.append("")
        
        return header + "\n".join(test_bodies)
    
    def regenerate_for_coverage(
        self,
        source_file: str,
        test_file: str,
        current_coverage: float,
        uncovered_lines: List[int],
        target_coverage: float = 90.0
    ) -> Dict[str, Any]:
        """
        Regenerate tests to improve coverage.
        
        Args:
            source_file: Path to the source file
            test_file: Path to the existing test file
            current_coverage: Current coverage percentage
            uncovered_lines: List of uncovered line numbers
            target_coverage: Target coverage to achieve
        
        Returns:
            Dictionary with regeneration results
        """
        source_path = Path(source_file)
        source_code = source_path.read_text(encoding='utf-8')
        lines = source_code.splitlines()
        
        # Extract uncovered code sections
        uncovered_sections = []
        for line_num in uncovered_lines:
            if 1 <= line_num <= len(lines):
                uncovered_sections.append(f"Line {line_num}: {lines[line_num - 1]}")
        
        # Build prompt for additional tests
        prompt = f"""The current test suite achieves {current_coverage:.1f}% coverage, but we need {target_coverage}%.

## Uncovered Lines
{chr(10).join(uncovered_sections[:20])}

## Source File
```python
{source_code}
```

## Existing Tests
```python
{Path(test_file).read_text(encoding='utf-8')}
```

Generate ADDITIONAL test cases that specifically target the uncovered lines.
Focus on:
1. Edge cases that would execute the uncovered branches
2. Error conditions that trigger uncovered exception handlers
3. Boundary conditions that exercise uncovered logic

Output ONLY the new test functions to add (not the entire file):"""
        
        response = self.llm_client.generate(prompt, SYSTEM_PROMPT)
        additional_tests = self._clean_generated_code(response.content)
        
        # Append to existing test file
        test_path = Path(test_file)
        existing_content = test_path.read_text(encoding='utf-8')
        
        new_content = existing_content + f"\n\n# Additional tests for improved coverage\n{additional_tests}\n"
        test_path.write_text(new_content, encoding='utf-8')
        
        return {
            "success": True,
            "test_file": str(test_path),
            "additional_tests_added": True,
            "previous_coverage": current_coverage,
            "target_coverage": target_coverage
        }

