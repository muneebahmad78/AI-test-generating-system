"""
Prompt Templates Module
=======================

Contains prompt templates for LLM-based test generation.
"""

# System prompt for test generation
SYSTEM_PROMPT = """You are an expert Python test engineer specializing in writing comprehensive PyTest unit tests.

Your task is to generate high-quality test cases that:
1. Follow PyTest best practices and conventions
2. Use descriptive test function names (test_<function>_<scenario>)
3. Include docstrings explaining what each test verifies
4. Cover normal cases, edge cases, and error scenarios
5. Use appropriate assertions (assert, pytest.raises, etc.)
6. Are self-contained and don't depend on external state
7. Use fixtures where appropriate for setup/teardown
8. Include parametrized tests for similar test cases

Output ONLY valid Python code. Do not include markdown code fences or explanations.
The code should be directly executable as a pytest test file."""


# Template for generating tests for a function
FUNCTION_TEST_TEMPLATE = """Generate comprehensive PyTest unit tests for the following Python {unit_type}:

## Source Code
```python
{source_code}
```

## Function Signature
{signature}

## Function Details
- Name: {qualified_name}
- Parameters: {parameters}
- Return Type: {return_type}
- Complexity: {complexity}
- Raises: {raises}

## Docstring
{docstring}

## Edge Cases to Cover
{edge_cases}

## Branch Coverage Requirements
The function has {branch_count} branches:
{branches}

## Requirements
1. Import the function from the module: `from {module_name} import {function_name}`
2. Write tests that achieve high branch coverage
3. Include tests for all edge cases listed above
4. Use pytest.raises for exception testing
5. Use pytest.mark.parametrize for similar test cases
6. Each test function should have a clear docstring

Generate the test code:"""


# Template for generating tests for a class
CLASS_TEST_TEMPLATE = """Generate comprehensive PyTest unit tests for the following Python class:

## Source Code
```python
{source_code}
```

## Class Details
- Name: {class_name}
- Base Classes: {bases}
- Methods: {methods}

## Docstring
{docstring}

## Methods to Test
{method_details}

## Edge Cases
{edge_cases}

## Requirements
1. Import the class: `from {module_name} import {class_name}`
2. Use fixtures for class instantiation
3. Test all public methods
4. Test edge cases for each method
5. Use pytest.raises for exception testing
6. Include docstrings for all tests

Generate the test code:"""


# Template for improving coverage
COVERAGE_IMPROVEMENT_TEMPLATE = """The current test suite achieves {current_coverage:.1f}% coverage, but we need {target_coverage}%.

## Uncovered Lines
{uncovered_lines}

## Source File
```python
{source_code}
```

## Existing Tests
```python
{existing_tests}
```

Generate ADDITIONAL test cases that specifically target the uncovered lines.
Focus on:
1. Edge cases that would execute the uncovered branches
2. Error conditions that trigger uncovered exception handlers
3. Boundary conditions that exercise uncovered logic

Output ONLY the new test functions to add (not the entire file):"""


# Template for edge case analysis
EDGE_CASE_ANALYSIS_TEMPLATE = """Analyze the following Python function and identify all possible edge cases that should be tested:

## Function Code
```python
{source_code}
```

## Function Signature
{signature}

## Parameters
{parameters}

List all edge cases in the following categories:
1. Null/None values
2. Empty collections/strings
3. Boundary values (min, max, zero)
4. Type errors
5. Exception scenarios
6. Special values (infinity, NaN for floats)

For each edge case, explain:
- What the test should do
- What the expected behavior is
- Why this edge case matters

Format as JSON:
{{
    "edge_cases": [
        {{
            "category": "null_empty",
            "description": "Test with None input",
            "test_input": null,
            "expected_behavior": "Should raise TypeError"
        }}
    ]
}}"""


def format_function_prompt(
    unit_type: str,
    source_code: str,
    signature: str,
    qualified_name: str,
    parameters: str,
    return_type: str,
    complexity: int,
    raises: str,
    docstring: str,
    edge_cases: str,
    branch_count: int,
    branches: str,
    module_name: str,
    function_name: str
) -> str:
    """Format the function test generation prompt."""
    return FUNCTION_TEST_TEMPLATE.format(
        unit_type=unit_type,
        source_code=source_code,
        signature=signature,
        qualified_name=qualified_name,
        parameters=parameters,
        return_type=return_type,
        complexity=complexity,
        raises=raises,
        docstring=docstring or "No docstring provided",
        edge_cases=edge_cases,
        branch_count=branch_count,
        branches=branches,
        module_name=module_name,
        function_name=function_name
    )


def format_class_prompt(
    source_code: str,
    class_name: str,
    bases: str,
    methods: str,
    docstring: str,
    method_details: str,
    edge_cases: str,
    module_name: str
) -> str:
    """Format the class test generation prompt."""
    return CLASS_TEST_TEMPLATE.format(
        source_code=source_code,
        class_name=class_name,
        bases=bases,
        methods=methods,
        docstring=docstring or "No docstring provided",
        method_details=method_details,
        edge_cases=edge_cases,
        module_name=module_name
    )


def format_coverage_prompt(
    current_coverage: float,
    target_coverage: float,
    uncovered_lines: str,
    source_code: str,
    existing_tests: str
) -> str:
    """Format the coverage improvement prompt."""
    return COVERAGE_IMPROVEMENT_TEMPLATE.format(
        current_coverage=current_coverage,
        target_coverage=target_coverage,
        uncovered_lines=uncovered_lines,
        source_code=source_code,
        existing_tests=existing_tests
    )

