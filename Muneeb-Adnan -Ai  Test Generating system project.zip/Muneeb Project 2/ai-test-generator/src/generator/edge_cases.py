"""
Edge Case Detection Module
==========================

Automatically detects and generates edge cases for test generation.
Handles null, empty, boundary values, and exception scenarios.
"""

from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum
import re


class EdgeCaseCategory(Enum):
    """Categories of edge cases."""
    NULL_EMPTY = "null_empty"
    BOUNDARY = "boundary"
    TYPE_ERROR = "type_error"
    EXCEPTION = "exception"
    SPECIAL_VALUES = "special_values"
    COLLECTION = "collection"
    STRING = "string"
    NUMERIC = "numeric"


@dataclass
class EdgeCase:
    """Represents an edge case for testing."""
    category: EdgeCaseCategory
    description: str
    input_value: Any
    expected_behavior: str
    priority: int  # 1 = highest priority


class EdgeCaseDetector:
    """
    Detects potential edge cases based on function signatures,
    type hints, and code analysis.
    """
    
    # Common type patterns
    NUMERIC_TYPES = {'int', 'float', 'Decimal', 'complex', 'Number'}
    STRING_TYPES = {'str', 'bytes', 'bytearray'}
    COLLECTION_TYPES = {'list', 'List', 'tuple', 'Tuple', 'set', 'Set', 
                        'dict', 'Dict', 'frozenset', 'FrozenSet'}
    OPTIONAL_PATTERN = re.compile(r'Optional\[(.+)\]|(.+)\s*\|\s*None|None\s*\|\s*(.+)')
    
    def __init__(self):
        self.edge_cases: List[EdgeCase] = []
    
    def detect_edge_cases(
        self,
        parameters: List[Dict[str, Any]],
        return_type: Optional[str] = None,
        raises: List[str] = None,
        source_code: str = ""
    ) -> List[EdgeCase]:
        """
        Detect edge cases based on function metadata.
        
        Args:
            parameters: List of parameter info dicts with 'name', 'type_hint', 'default'
            return_type: Return type annotation
            raises: List of exception types the function can raise
            source_code: The function source code for additional analysis
        
        Returns:
            List of detected edge cases
        """
        self.edge_cases = []
        
        for param in parameters:
            # Skip self parameter
            if param.get('name') == 'self':
                continue
            
            param_cases = self._detect_parameter_edge_cases(param, source_code)
            self.edge_cases.extend(param_cases)
        
        # Add exception-based edge cases
        if raises:
            for exc in raises:
                self.edge_cases.append(EdgeCase(
                    category=EdgeCaseCategory.EXCEPTION,
                    description=f"Should raise {exc}",
                    input_value=None,
                    expected_behavior=f"raises {exc}",
                    priority=1
                ))
        
        # Analyze code for additional edge cases
        code_cases = self._analyze_code_for_edge_cases(source_code)
        self.edge_cases.extend(code_cases)
        
        # Sort by priority
        self.edge_cases.sort(key=lambda x: x.priority)
        
        return self.edge_cases
    
    def _detect_parameter_edge_cases(
        self,
        param: Dict[str, Any],
        source_code: str
    ) -> List[EdgeCase]:
        """Detect edge cases for a single parameter."""
        cases = []
        name = param.get('name', 'param')
        type_hint = param.get('type_hint', '')
        default = param.get('default')
        
        # Check if parameter is Optional
        is_optional = self._is_optional_type(type_hint)
        
        # Null/None edge cases
        if is_optional or not type_hint:
            cases.append(EdgeCase(
                category=EdgeCaseCategory.NULL_EMPTY,
                description=f"Test {name} with None value",
                input_value=None,
                expected_behavior="handles None appropriately",
                priority=1
            ))
        
        # Type-specific edge cases
        if type_hint:
            base_type = self._extract_base_type(type_hint)
            
            if base_type in self.NUMERIC_TYPES or 'int' in name.lower() or 'num' in name.lower():
                cases.extend(self._get_numeric_edge_cases(name))
            
            if base_type in self.STRING_TYPES or 'str' in name.lower() or 'name' in name.lower():
                cases.extend(self._get_string_edge_cases(name))
            
            if base_type in self.COLLECTION_TYPES or 'list' in name.lower() or 'arr' in name.lower():
                cases.extend(self._get_collection_edge_cases(name, base_type))
        
        # Name-based heuristics
        cases.extend(self._get_name_based_edge_cases(name, source_code))
        
        return cases
    
    def _get_numeric_edge_cases(self, param_name: str) -> List[EdgeCase]:
        """Get edge cases for numeric parameters."""
        return [
            EdgeCase(
                category=EdgeCaseCategory.BOUNDARY,
                description=f"Test {param_name} with zero",
                input_value=0,
                expected_behavior="handles zero correctly",
                priority=1
            ),
            EdgeCase(
                category=EdgeCaseCategory.BOUNDARY,
                description=f"Test {param_name} with negative number",
                input_value=-1,
                expected_behavior="handles negative values",
                priority=2
            ),
            EdgeCase(
                category=EdgeCaseCategory.BOUNDARY,
                description=f"Test {param_name} with large number",
                input_value=10**9,
                expected_behavior="handles large values",
                priority=3
            ),
            EdgeCase(
                category=EdgeCaseCategory.SPECIAL_VALUES,
                description=f"Test {param_name} with float (if int expected)",
                input_value=1.5,
                expected_behavior="handles float input",
                priority=3
            ),
        ]
    
    def _get_string_edge_cases(self, param_name: str) -> List[EdgeCase]:
        """Get edge cases for string parameters."""
        return [
            EdgeCase(
                category=EdgeCaseCategory.NULL_EMPTY,
                description=f"Test {param_name} with empty string",
                input_value="",
                expected_behavior="handles empty string",
                priority=1
            ),
            EdgeCase(
                category=EdgeCaseCategory.STRING,
                description=f"Test {param_name} with whitespace only",
                input_value="   ",
                expected_behavior="handles whitespace-only string",
                priority=2
            ),
            EdgeCase(
                category=EdgeCaseCategory.STRING,
                description=f"Test {param_name} with special characters",
                input_value="!@#$%^&*()",
                expected_behavior="handles special characters",
                priority=2
            ),
            EdgeCase(
                category=EdgeCaseCategory.STRING,
                description=f"Test {param_name} with unicode",
                input_value="日本語テスト🎉",
                expected_behavior="handles unicode characters",
                priority=3
            ),
            EdgeCase(
                category=EdgeCaseCategory.BOUNDARY,
                description=f"Test {param_name} with very long string",
                input_value="a" * 10000,
                expected_behavior="handles long strings",
                priority=3
            ),
        ]
    
    def _get_collection_edge_cases(self, param_name: str, type_hint: str) -> List[EdgeCase]:
        """Get edge cases for collection parameters."""
        cases = [
            EdgeCase(
                category=EdgeCaseCategory.NULL_EMPTY,
                description=f"Test {param_name} with empty collection",
                input_value="[]" if 'list' in type_hint.lower() else "{}",
                expected_behavior="handles empty collection",
                priority=1
            ),
            EdgeCase(
                category=EdgeCaseCategory.COLLECTION,
                description=f"Test {param_name} with single element",
                input_value="[1]" if 'list' in type_hint.lower() else "{'key': 'value'}",
                expected_behavior="handles single-element collection",
                priority=2
            ),
            EdgeCase(
                category=EdgeCaseCategory.BOUNDARY,
                description=f"Test {param_name} with large collection",
                input_value="list(range(1000))",
                expected_behavior="handles large collections",
                priority=3
            ),
        ]
        
        if 'list' in type_hint.lower():
            cases.append(EdgeCase(
                category=EdgeCaseCategory.COLLECTION,
                description=f"Test {param_name} with None elements",
                input_value="[None, 1, None]",
                expected_behavior="handles None elements in list",
                priority=2
            ))
        
        return cases
    
    def _get_name_based_edge_cases(self, param_name: str, source_code: str) -> List[EdgeCase]:
        """Get edge cases based on parameter naming conventions."""
        cases = []
        name_lower = param_name.lower()
        
        # File/path related
        if any(x in name_lower for x in ['file', 'path', 'dir', 'folder']):
            cases.extend([
                EdgeCase(
                    category=EdgeCaseCategory.EXCEPTION,
                    description=f"Test {param_name} with non-existent path",
                    input_value="/nonexistent/path/to/file.txt",
                    expected_behavior="handles missing file",
                    priority=1
                ),
                EdgeCase(
                    category=EdgeCaseCategory.STRING,
                    description=f"Test {param_name} with invalid path characters",
                    input_value="invalid<>path",
                    expected_behavior="handles invalid path",
                    priority=2
                ),
            ])
        
        # Index/position related
        if any(x in name_lower for x in ['index', 'idx', 'position', 'pos']):
            cases.extend([
                EdgeCase(
                    category=EdgeCaseCategory.BOUNDARY,
                    description=f"Test {param_name} with negative index",
                    input_value=-1,
                    expected_behavior="handles negative index",
                    priority=1
                ),
                EdgeCase(
                    category=EdgeCaseCategory.BOUNDARY,
                    description=f"Test {param_name} with out-of-bounds index",
                    input_value=999999,
                    expected_behavior="handles out-of-bounds",
                    priority=1
                ),
            ])
        
        # Date/time related
        if any(x in name_lower for x in ['date', 'time', 'datetime', 'timestamp']):
            cases.extend([
                EdgeCase(
                    category=EdgeCaseCategory.SPECIAL_VALUES,
                    description=f"Test {param_name} with epoch time",
                    input_value="datetime(1970, 1, 1)",
                    expected_behavior="handles epoch",
                    priority=2
                ),
                EdgeCase(
                    category=EdgeCaseCategory.SPECIAL_VALUES,
                    description=f"Test {param_name} with future date",
                    input_value="datetime(2099, 12, 31)",
                    expected_behavior="handles future dates",
                    priority=3
                ),
            ])
        
        # Email related
        if 'email' in name_lower:
            cases.extend([
                EdgeCase(
                    category=EdgeCaseCategory.STRING,
                    description=f"Test {param_name} with invalid email",
                    input_value="not-an-email",
                    expected_behavior="validates email format",
                    priority=1
                ),
                EdgeCase(
                    category=EdgeCaseCategory.STRING,
                    description=f"Test {param_name} with email-like string",
                    input_value="almost@valid",
                    expected_behavior="validates email properly",
                    priority=2
                ),
            ])
        
        # URL related
        if any(x in name_lower for x in ['url', 'uri', 'link', 'href']):
            cases.extend([
                EdgeCase(
                    category=EdgeCaseCategory.STRING,
                    description=f"Test {param_name} with invalid URL",
                    input_value="not-a-url",
                    expected_behavior="validates URL format",
                    priority=1
                ),
                EdgeCase(
                    category=EdgeCaseCategory.STRING,
                    description=f"Test {param_name} with malformed URL",
                    input_value="http://",
                    expected_behavior="handles malformed URL",
                    priority=2
                ),
            ])
        
        return cases
    
    def _analyze_code_for_edge_cases(self, source_code: str) -> List[EdgeCase]:
        """Analyze source code for additional edge case opportunities."""
        cases = []
        
        # Check for division operations
        if '/' in source_code and '//' not in source_code.replace('//', ''):
            cases.append(EdgeCase(
                category=EdgeCaseCategory.EXCEPTION,
                description="Test division by zero scenario",
                input_value=0,
                expected_behavior="handles division by zero",
                priority=1
            ))
        
        # Check for indexing operations
        if '[' in source_code and ']' in source_code:
            cases.append(EdgeCase(
                category=EdgeCaseCategory.EXCEPTION,
                description="Test with empty collection for indexing",
                input_value=[],
                expected_behavior="handles empty collection indexing",
                priority=1
            ))
        
        # Check for comparisons with None
        if 'is None' in source_code or '== None' in source_code:
            cases.append(EdgeCase(
                category=EdgeCaseCategory.NULL_EMPTY,
                description="Test None handling path",
                input_value=None,
                expected_behavior="correctly handles None comparison",
                priority=1
            ))
        
        # Check for string operations
        if '.strip()' in source_code or '.split()' in source_code:
            cases.append(EdgeCase(
                category=EdgeCaseCategory.STRING,
                description="Test with string containing only delimiters",
                input_value="   \t\n   ",
                expected_behavior="handles whitespace-only strings",
                priority=2
            ))
        
        return cases
    
    def _is_optional_type(self, type_hint: str) -> bool:
        """Check if a type hint indicates an optional type."""
        if not type_hint:
            return False
        return bool(self.OPTIONAL_PATTERN.match(type_hint)) or type_hint == 'None'
    
    def _extract_base_type(self, type_hint: str) -> str:
        """Extract the base type from a type hint."""
        # Handle Optional[X]
        match = self.OPTIONAL_PATTERN.match(type_hint)
        if match:
            return match.group(1) or match.group(2) or match.group(3)
        
        # Handle List[X], Dict[K, V], etc.
        if '[' in type_hint:
            return type_hint.split('[')[0]
        
        return type_hint
    
    def get_edge_cases_by_category(self, category: EdgeCaseCategory) -> List[EdgeCase]:
        """Filter edge cases by category."""
        return [ec for ec in self.edge_cases if ec.category == category]
    
    def get_high_priority_cases(self, max_priority: int = 2) -> List[EdgeCase]:
        """Get edge cases up to a certain priority level."""
        return [ec for ec in self.edge_cases if ec.priority <= max_priority]
    
    def to_test_inputs(self) -> List[Dict[str, Any]]:
        """Convert edge cases to test input dictionaries."""
        return [
            {
                "category": ec.category.value,
                "description": ec.description,
                "input": ec.input_value,
                "expected": ec.expected_behavior
            }
            for ec in self.edge_cases
        ]

