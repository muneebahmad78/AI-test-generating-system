"""
LLM Client Module
=================

Provides a unified interface for interacting with various LLM providers
(OpenAI, Anthropic Claude) for test generation.
"""

import os
import json
from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from enum import Enum


class LLMProvider(Enum):
    """Supported LLM providers."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LOCAL = "local"  # For testing without API


@dataclass
class LLMResponse:
    """Response from LLM."""
    content: str
    model: str
    provider: str
    usage: Dict[str, int]
    raw_response: Optional[Any] = None


class BaseLLMClient(ABC):
    """Base class for LLM clients."""
    
    @abstractmethod
    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> LLMResponse:
        """Generate a response from the LLM."""
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """Check if the LLM client is properly configured."""
        pass


class OpenAIClient(BaseLLMClient):
    """OpenAI GPT client."""
    
    def __init__(self, model: str = "gpt-4o", api_key: Optional[str] = None):
        self.model = model
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self._client = None
    
    def _get_client(self):
        if self._client is None:
            try:
                from openai import OpenAI
                self._client = OpenAI(api_key=self.api_key)
            except ImportError:
                raise ImportError("OpenAI package not installed. Run: pip install openai")
        return self._client
    
    def is_available(self) -> bool:
        return self.api_key is not None
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> LLMResponse:
        client = self._get_client()
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        response = client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.3,
            max_tokens=4096
        )
        
        return LLMResponse(
            content=response.choices[0].message.content,
            model=self.model,
            provider="openai",
            usage={
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens
            },
            raw_response=response
        )


class AnthropicClient(BaseLLMClient):
    """Anthropic Claude client."""
    
    def __init__(self, model: str = "claude-sonnet-4-20250514", api_key: Optional[str] = None):
        self.model = model
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self._client = None
    
    def _get_client(self):
        if self._client is None:
            try:
                from anthropic import Anthropic
                self._client = Anthropic(api_key=self.api_key)
            except ImportError:
                raise ImportError("Anthropic package not installed. Run: pip install anthropic")
        return self._client
    
    def is_available(self) -> bool:
        return self.api_key is not None
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> LLMResponse:
        client = self._get_client()
        
        kwargs = {
            "model": self.model,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": prompt}]
        }
        
        if system_prompt:
            kwargs["system"] = system_prompt
        
        response = client.messages.create(**kwargs)
        
        return LLMResponse(
            content=response.content[0].text,
            model=self.model,
            provider="anthropic",
            usage={
                "prompt_tokens": response.usage.input_tokens,
                "completion_tokens": response.usage.output_tokens,
                "total_tokens": response.usage.input_tokens + response.usage.output_tokens
            },
            raw_response=response
        )


class LocalLLMClient(BaseLLMClient):
    """
    Local/Mock LLM client for testing without API.
    
    Uses template-based generation for basic test cases.
    """
    
    def __init__(self):
        self.model = "local-template"
    
    def is_available(self) -> bool:
        return True
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> LLMResponse:
        """Generate basic test templates based on patterns in the prompt."""
        # Extract function name from prompt
        import re
        
        func_match = re.search(r'def\s+(\w+)\s*\(', prompt)
        func_name = func_match.group(1) if func_match else "unknown_function"
        
        # Extract parameters
        params_match = re.search(r'def\s+\w+\s*\((.*?)\)', prompt)
        params = params_match.group(1) if params_match else ""
        
        # Generate basic test template
        test_code = self._generate_template(func_name, params, prompt)
        
        return LLMResponse(
            content=test_code,
            model=self.model,
            provider="local",
            usage={"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        )
    
    def _generate_template(self, func_name: str, params: str, prompt: str) -> str:
        """Generate a basic test template."""
        param_list = [p.strip().split(':')[0].split('=')[0].strip() 
                      for p in params.split(',') if p.strip() and p.strip() != 'self']
        
        # Build test cases
        tests = []
        
        # Basic test
        test_args = ", ".join([self._get_default_arg(p) for p in param_list])
        tests.append(f'''
def test_{func_name}_basic():
    """Test {func_name} with basic inputs."""
    result = {func_name}({test_args})
    assert result is not None
''')
        
        # Edge case tests
        if param_list:
            tests.append(f'''
def test_{func_name}_empty_input():
    """Test {func_name} with empty/None inputs."""
    # Test with edge case values
    pass  # Implement based on function signature
''')
        
        # Exception test if 'raise' in prompt
        if 'raise' in prompt.lower():
            tests.append(f'''
def test_{func_name}_raises_exception():
    """Test that {func_name} raises expected exceptions."""
    import pytest
    with pytest.raises(Exception):
        {func_name}()  # Add invalid arguments
''')
        
        return "\n".join(tests)
    
    def _get_default_arg(self, param: str) -> str:
        """Get a default argument value based on parameter name."""
        param_lower = param.lower()
        
        if 'str' in param_lower or 'name' in param_lower or 'text' in param_lower:
            return '"test"'
        elif 'int' in param_lower or 'num' in param_lower or 'count' in param_lower:
            return '1'
        elif 'float' in param_lower:
            return '1.0'
        elif 'list' in param_lower or 'arr' in param_lower:
            return '[]'
        elif 'dict' in param_lower:
            return '{}'
        elif 'bool' in param_lower or 'flag' in param_lower:
            return 'True'
        else:
            return 'None'


class LLMClient:
    """
    Unified LLM client that automatically selects the best available provider.
    """
    
    def __init__(
        self,
        provider: Optional[LLMProvider] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None
    ):
        self.provider = provider
        self.model = model
        self.api_key = api_key
        self._client: Optional[BaseLLMClient] = None
        self._initialize_client()
    
    def _initialize_client(self):
        """Initialize the appropriate LLM client."""
        if self.provider == LLMProvider.OPENAI:
            self._client = OpenAIClient(
                model=self.model or "gpt-4o",
                api_key=self.api_key
            )
        elif self.provider == LLMProvider.ANTHROPIC:
            self._client = AnthropicClient(
                model=self.model or "claude-sonnet-4-20250514",
                api_key=self.api_key
            )
        elif self.provider == LLMProvider.LOCAL:
            self._client = LocalLLMClient()
        else:
            # Auto-detect best available provider
            self._client = self._auto_detect_provider()
    
    def _auto_detect_provider(self) -> BaseLLMClient:
        """Auto-detect the best available LLM provider."""
        # Try Anthropic first (user preference)
        anthropic_client = AnthropicClient()
        if anthropic_client.is_available():
            return anthropic_client
        
        # Try OpenAI
        openai_client = OpenAIClient()
        if openai_client.is_available():
            return openai_client
        
        # Fall back to local
        return LocalLLMClient()
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> LLMResponse:
        """Generate a response from the LLM."""
        return self._client.generate(prompt, system_prompt)
    
    def is_available(self) -> bool:
        """Check if the LLM client is properly configured."""
        return self._client.is_available()
    
    @property
    def provider_name(self) -> str:
        """Get the name of the current provider."""
        if isinstance(self._client, OpenAIClient):
            return "OpenAI"
        elif isinstance(self._client, AnthropicClient):
            return "Anthropic Claude"
        else:
            return "Local Template"

