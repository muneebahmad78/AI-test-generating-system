"""
CLI Module
==========

Command-line interface for the AI Test Generator.
"""

import sys
from pathlib import Path
from typing import Optional

try:
    import click
    from rich.console import Console
    from rich.panel import Panel
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
    click = None

from .analyzer.code_parser import CodeParser
from .generator.test_generator import TestGenerator
from .generator.llm_client import LLMProvider
from .executor.test_runner import TestRunner
from .executor.coverage_analyzer import CoverageAnalyzer
from .reporter.coverage_report import CoverageReporter


def create_cli():
    """Create and configure the CLI application."""
    
    if click is None:
        print("Error: 'click' package is required. Install with: pip install click")
        sys.exit(1)
    
    @click.group()
    @click.version_option(version="1.0.0")
    def cli():
        """
        AI-Powered Automated Test Generator for Python
        
        Generate comprehensive PyTest unit tests using AI-based reasoning.
        Achieve ≥90% code coverage automatically.
        """
        pass
    
    @cli.command()
    @click.argument('source_file', type=click.Path(exists=True))
    @click.option('--output', '-o', default='tests', 
                  help='Output directory for generated tests')
    @click.option('--provider', '-p', 
                  type=click.Choice(['openai', 'anthropic', 'local']),
                  default=None, help='LLM provider to use')
    @click.option('--model', '-m', default=None,
                  help='Specific model to use')
    @click.option('--api-key', '-k', default=None,
                  help='API key for the LLM provider')
    @click.option('--target-coverage', '-c', default=90.0,
                  help='Target coverage percentage (default: 90)')
    @click.option('--max-iterations', '-i', default=3,
                  help='Maximum regeneration iterations')
    @click.option('--run-tests/--no-run-tests', default=True,
                  help='Run generated tests after creation')
    @click.option('--verbose', '-v', is_flag=True,
                  help='Enable verbose output')
    def generate(
        source_file: str,
        output: str,
        provider: Optional[str],
        model: Optional[str],
        api_key: Optional[str],
        target_coverage: float,
        max_iterations: int,
        run_tests: bool,
        verbose: bool
    ):
        """
        Generate unit tests for a Python source file.
        
        Example:
            python -m ai_test_generator generate my_module.py
        """
        reporter = CoverageReporter()
        
        # Display header
        if RICH_AVAILABLE:
            console = Console()
            console.print(Panel(
                "[bold cyan]AI Test Generator[/bold cyan]\n"
                f"Source: {source_file}\n"
                f"Target Coverage: {target_coverage}%",
                title="🧪 Test Generation",
                border_style="cyan"
            ))
        else:
            print("=" * 60)
            print("  AI Test Generator")
            print(f"  Source: {source_file}")
            print(f"  Target Coverage: {target_coverage}%")
            print("=" * 60)
        
        # Determine LLM provider
        llm_provider = None
        if provider:
            provider_map = {
                'openai': LLMProvider.OPENAI,
                'anthropic': LLMProvider.ANTHROPIC,
                'local': LLMProvider.LOCAL
            }
            llm_provider = provider_map.get(provider)
        
        # Initialize generator
        reporter.display_info("Initializing test generator...")
        generator = TestGenerator(
            llm_provider=llm_provider,
            model=model,
            api_key=api_key
        )
        
        reporter.display_info(f"Using LLM provider: {generator.llm_client.provider_name}")
        
        # Analyze source file
        reporter.display_test_generation_progress("Analyzing source code...")
        source_path = Path(source_file)
        
        try:
            parser = CodeParser(
                source_path.read_text(encoding='utf-8'),
                str(source_path)
            )
            module_info = parser.parse()
            testable_units = parser.get_testable_units()
            
            reporter.display_info(
                f"Found {len(testable_units)} testable units "
                f"({len(module_info.functions)} functions, {len(module_info.classes)} classes)"
            )
        except Exception as e:
            reporter.display_error(f"Failed to analyze source: {e}")
            sys.exit(1)
        
        # Generate tests
        reporter.display_test_generation_progress("Generating tests with AI...")
        
        try:
            result = generator.generate_tests(
                source_file=source_file,
                output_dir=output,
                min_coverage=target_coverage
            )
            
            if not result.get('success'):
                reporter.display_error(result.get('message', 'Test generation failed'))
                sys.exit(1)
            
            test_file = result['test_file']
            reporter.display_success(f"Generated tests: {test_file}")
            reporter.display_info(f"Tests generated: {result['tests_generated']}")
        
        except Exception as e:
            reporter.display_error(f"Test generation failed: {e}")
            if verbose:
                import traceback
                traceback.print_exc()
            sys.exit(1)
        
        # Run tests if requested
        if run_tests:
            current_coverage = 0.0
            iteration = 0
            
            while iteration < max_iterations:
                iteration += 1
                
                reporter.display_test_generation_progress(
                    f"Running tests (iteration {iteration}/{max_iterations})..."
                )
                
                # Run tests with coverage
                runner = TestRunner(working_dir=str(Path(source_file).parent))
                coverage_analyzer = CoverageAnalyzer(working_dir=str(Path(source_file).parent))
                
                try:
                    # Run with coverage
                    coverage_report = coverage_analyzer.run_with_coverage(
                        test_path=test_file,
                        source_path=source_file
                    )
                    
                    # Get test results
                    test_result = runner.run_tests(
                        test_path=test_file,
                        source_path=source_file,
                        with_coverage=False
                    )
                    
                    # Display test results
                    reporter.display_test_results(
                        passed=test_result.passed,
                        failed=test_result.failed,
                        errors=test_result.errors,
                        skipped=test_result.skipped,
                        duration=test_result.duration
                    )
                    
                    # Display coverage
                    reporter.display_summary(coverage_report, target_coverage)
                    
                    if verbose:
                        reporter.display_file_details(coverage_report)
                        reporter.display_uncovered_lines(coverage_report)
                    
                    current_coverage = coverage_report.coverage_percent
                    
                    # Check if target met
                    if current_coverage >= target_coverage:
                        reporter.display_success(
                            f"Target coverage of {target_coverage}% achieved!"
                        )
                        break
                    
                    # Regenerate if more iterations available
                    if iteration < max_iterations:
                        reporter.display_regeneration_notice(
                            current_coverage, target_coverage
                        )
                        
                        uncovered = coverage_analyzer.get_uncovered_lines(source_file)
                        
                        if uncovered:
                            generator.regenerate_for_coverage(
                                source_file=source_file,
                                test_file=test_file,
                                current_coverage=current_coverage,
                                uncovered_lines=uncovered,
                                target_coverage=target_coverage
                            )
                            reporter.display_info("Additional tests generated")
                
                except Exception as e:
                    reporter.display_error(f"Test execution failed: {e}")
                    if verbose:
                        import traceback
                        traceback.print_exc()
                    break
            
            # Final status
            if current_coverage >= target_coverage:
                reporter.display_success(
                    f"✨ Test generation complete! Coverage: {current_coverage:.1f}%"
                )
            else:
                reporter.display_warning(
                    f"Coverage {current_coverage:.1f}% is below target {target_coverage}%. "
                    "Consider manual test additions."
                )
        
        reporter.display_success(f"Tests saved to: {test_file}")
    
    @cli.command()
    @click.argument('source_file', type=click.Path(exists=True))
    @click.option('--verbose', '-v', is_flag=True, help='Show detailed analysis')
    def analyze(source_file: str, verbose: bool):
        """
        Analyze a Python source file without generating tests.
        
        Shows functions, classes, complexity, and potential edge cases.
        """
        reporter = CoverageReporter()
        
        reporter.display_info(f"Analyzing: {source_file}")
        
        source_path = Path(source_file)
        parser = CodeParser(
            source_path.read_text(encoding='utf-8'),
            str(source_path)
        )
        module_info = parser.parse()
        testable_units = parser.get_testable_units()
        
        if RICH_AVAILABLE:
            from rich.table import Table
            from rich import box
            console = Console()
            
            # Functions table
            if module_info.functions:
                table = Table(title="Functions", box=box.ROUNDED)
                table.add_column("Name")
                table.add_column("Parameters")
                table.add_column("Returns")
                table.add_column("Complexity")
                
                for func in module_info.functions:
                    params = ", ".join(a['name'] for a in func.args)
                    table.add_row(
                        func.name,
                        params or "(none)",
                        func.returns or "None",
                        str(func.complexity)
                    )
                
                console.print(table)
            
            # Classes table
            if module_info.classes:
                table = Table(title="Classes", box=box.ROUNDED)
                table.add_column("Name")
                table.add_column("Methods")
                table.add_column("Bases")
                
                for cls in module_info.classes:
                    methods = ", ".join(m.name for m in cls.methods[:5])
                    if len(cls.methods) > 5:
                        methods += f" (+{len(cls.methods) - 5} more)"
                    table.add_row(
                        cls.name,
                        methods or "(none)",
                        ", ".join(cls.bases) or "(none)"
                    )
                
                console.print(table)
            
            # Testable units summary
            console.print(f"\n[bold]Testable Units:[/bold] {len(testable_units)}")
            
            if verbose:
                for unit in testable_units:
                    console.print(f"  • {unit.qualified_name} (complexity: {unit.complexity})")
        else:
            print(f"\nFunctions: {len(module_info.functions)}")
            for func in module_info.functions:
                print(f"  - {func.name}()")
            
            print(f"\nClasses: {len(module_info.classes)}")
            for cls in module_info.classes:
                print(f"  - {cls.name}")
            
            print(f"\nTestable Units: {len(testable_units)}")
    
    @cli.command()
    @click.argument('test_file', type=click.Path(exists=True))
    @click.argument('source_file', type=click.Path(exists=True))
    @click.option('--html', is_flag=True, help='Generate HTML report')
    def coverage(test_file: str, source_file: str, html: bool):
        """
        Run tests and display coverage report.
        """
        reporter = CoverageReporter()
        
        reporter.display_info("Running tests with coverage measurement...")
        
        coverage_analyzer = CoverageAnalyzer(
            working_dir=str(Path(source_file).parent)
        )
        
        report = coverage_analyzer.run_with_coverage(
            test_path=test_file,
            source_path=source_file
        )
        
        reporter.display_summary(report)
        reporter.display_file_details(report)
        reporter.display_uncovered_lines(report)
        
        if html:
            html_path = coverage_analyzer.generate_html_report()
            reporter.display_success(f"HTML report generated: {html_path}")
    
    @cli.command()
    @click.argument('test_file', type=click.Path(exists=True))
    @click.option('--verbose', '-v', is_flag=True, help='Verbose output')
    def run(test_file: str, verbose: bool):
        """
        Run tests without generating new ones.
        """
        reporter = CoverageReporter()
        
        reporter.display_info(f"Running tests: {test_file}")
        
        runner = TestRunner()
        result = runner.run_tests(test_file, verbose=verbose)
        
        reporter.display_test_results(
            passed=result.passed,
            failed=result.failed,
            errors=result.errors,
            skipped=result.skipped,
            duration=result.duration
        )
        
        if result.failed > 0 or result.errors > 0:
            sys.exit(1)
    
    return cli


def main():
    """Main entry point."""
    cli = create_cli()
    cli()


if __name__ == "__main__":
    main()

