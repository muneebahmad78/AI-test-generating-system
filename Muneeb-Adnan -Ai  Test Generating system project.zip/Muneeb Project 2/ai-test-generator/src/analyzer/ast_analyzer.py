"""
AST Analyzer Module
===================

Performs static code analysis using Python's Abstract Syntax Tree.
Detects functions, classes, branches, and logic patterns.
"""

import ast
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Set
from pathlib import Path


@dataclass
class FunctionInfo:
    """Information about a function or method."""
    name: str
    args: List[Dict[str, Any]]
    returns: Optional[str]
    docstring: Optional[str]
    decorators: List[str]
    is_async: bool
    is_method: bool
    class_name: Optional[str]
    start_line: int
    end_line: int
    complexity: int
    branches: List[Dict[str, Any]]
    source_code: str
    raises: List[str] = field(default_factory=list)


@dataclass
class ClassInfo:
    """Information about a class."""
    name: str
    bases: List[str]
    docstring: Optional[str]
    methods: List[FunctionInfo]
    class_variables: List[Dict[str, Any]]
    decorators: List[str]
    start_line: int
    end_line: int


@dataclass
class ModuleInfo:
    """Information about a Python module."""
    name: str
    docstring: Optional[str]
    imports: List[str]
    functions: List[FunctionInfo]
    classes: List[ClassInfo]
    global_variables: List[Dict[str, Any]]
    source_code: str


class ASTAnalyzer:
    """
    Analyzes Python source code using AST.
    
    Extracts comprehensive information about:
    - Functions and their signatures
    - Classes and their methods
    - Control flow branches
    - Exception handling
    - Type hints
    """
    
    def __init__(self, source_code: str, filename: str = "<unknown>"):
        self.source_code = source_code
        self.filename = filename
        self.lines = source_code.splitlines()
        self._tree: Optional[ast.AST] = None
    
    def parse(self) -> ast.AST:
        """Parse the source code into an AST."""
        try:
            self._tree = ast.parse(self.source_code, filename=self.filename)
            return self._tree
        except SyntaxError as e:
            raise ValueError(f"Syntax error in {self.filename}: {e}")
    
    def analyze(self) -> ModuleInfo:
        """Perform complete analysis of the source code."""
        if self._tree is None:
            self.parse()
        
        return ModuleInfo(
            name=Path(self.filename).stem,
            docstring=ast.get_docstring(self._tree),
            imports=self._extract_imports(),
            functions=self._extract_functions(),
            classes=self._extract_classes(),
            global_variables=self._extract_global_variables(),
            source_code=self.source_code
        )
    
    def _extract_imports(self) -> List[str]:
        """Extract all import statements."""
        imports = []
        for node in ast.walk(self._tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    imports.append(f"{module}.{alias.name}")
        return imports
    
    def _extract_functions(self) -> List[FunctionInfo]:
        """Extract all top-level functions."""
        functions = []
        for node in ast.iter_child_nodes(self._tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                functions.append(self._analyze_function(node))
        return functions
    
    def _extract_classes(self) -> List[ClassInfo]:
        """Extract all classes with their methods."""
        classes = []
        for node in ast.iter_child_nodes(self._tree):
            if isinstance(node, ast.ClassDef):
                classes.append(self._analyze_class(node))
        return classes
    
    def _extract_global_variables(self) -> List[Dict[str, Any]]:
        """Extract global variable assignments."""
        variables = []
        for node in ast.iter_child_nodes(self._tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        variables.append({
                            "name": target.id,
                            "line": node.lineno,
                            "type_hint": None
                        })
            elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                variables.append({
                    "name": node.target.id,
                    "line": node.lineno,
                    "type_hint": self._get_annotation_string(node.annotation)
                })
        return variables
    
    def _analyze_function(self, node: ast.FunctionDef, class_name: Optional[str] = None) -> FunctionInfo:
        """Analyze a function or method definition."""
        args = self._extract_arguments(node.args)
        returns = self._get_annotation_string(node.returns) if node.returns else None
        decorators = [self._get_decorator_name(d) for d in node.decorator_list]
        branches = self._extract_branches(node)
        raises = self._extract_raises(node)
        
        # Get source code for this function
        start_line = node.lineno - 1
        end_line = node.end_lineno if hasattr(node, 'end_lineno') else start_line + 1
        source_lines = self.lines[start_line:end_line]
        source_code = "\n".join(source_lines)
        
        return FunctionInfo(
            name=node.name,
            args=args,
            returns=returns,
            docstring=ast.get_docstring(node),
            decorators=decorators,
            is_async=isinstance(node, ast.AsyncFunctionDef),
            is_method=class_name is not None,
            class_name=class_name,
            start_line=node.lineno,
            end_line=end_line,
            complexity=self._calculate_complexity(node),
            branches=branches,
            source_code=source_code,
            raises=raises
        )
    
    def _analyze_class(self, node: ast.ClassDef) -> ClassInfo:
        """Analyze a class definition."""
        methods = []
        class_variables = []
        
        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                methods.append(self._analyze_function(item, class_name=node.name))
            elif isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        class_variables.append({
                            "name": target.id,
                            "line": item.lineno,
                            "type_hint": None
                        })
            elif isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                class_variables.append({
                    "name": item.target.id,
                    "line": item.lineno,
                    "type_hint": self._get_annotation_string(item.annotation)
                })
        
        bases = [self._get_node_name(base) for base in node.bases]
        decorators = [self._get_decorator_name(d) for d in node.decorator_list]
        
        return ClassInfo(
            name=node.name,
            bases=bases,
            docstring=ast.get_docstring(node),
            methods=methods,
            class_variables=class_variables,
            decorators=decorators,
            start_line=node.lineno,
            end_line=node.end_lineno if hasattr(node, 'end_lineno') else node.lineno
        )
    
    def _extract_arguments(self, args: ast.arguments) -> List[Dict[str, Any]]:
        """Extract function arguments with type hints and defaults."""
        result = []
        
        # Calculate defaults offset
        num_args = len(args.args)
        num_defaults = len(args.defaults)
        defaults_offset = num_args - num_defaults
        
        for i, arg in enumerate(args.args):
            default_idx = i - defaults_offset
            default = None
            if default_idx >= 0 and default_idx < len(args.defaults):
                default = self._get_default_value(args.defaults[default_idx])
            
            result.append({
                "name": arg.arg,
                "type_hint": self._get_annotation_string(arg.annotation) if arg.annotation else None,
                "default": default,
                "kind": "positional_or_keyword"
            })
        
        # Handle *args
        if args.vararg:
            result.append({
                "name": args.vararg.arg,
                "type_hint": self._get_annotation_string(args.vararg.annotation) if args.vararg.annotation else None,
                "default": None,
                "kind": "var_positional"
            })
        
        # Handle keyword-only args
        for i, arg in enumerate(args.kwonlyargs):
            default = None
            if i < len(args.kw_defaults) and args.kw_defaults[i] is not None:
                default = self._get_default_value(args.kw_defaults[i])
            
            result.append({
                "name": arg.arg,
                "type_hint": self._get_annotation_string(arg.annotation) if arg.annotation else None,
                "default": default,
                "kind": "keyword_only"
            })
        
        # Handle **kwargs
        if args.kwarg:
            result.append({
                "name": args.kwarg.arg,
                "type_hint": self._get_annotation_string(args.kwarg.annotation) if args.kwarg.annotation else None,
                "default": None,
                "kind": "var_keyword"
            })
        
        return result
    
    def _extract_branches(self, node: ast.AST) -> List[Dict[str, Any]]:
        """Extract all branching logic (if/elif/else, for, while, try/except)."""
        branches = []
        
        for child in ast.walk(node):
            if isinstance(child, ast.If):
                branches.append({
                    "type": "if",
                    "line": child.lineno,
                    "condition": ast.unparse(child.test) if hasattr(ast, 'unparse') else str(child.test),
                    "has_else": len(child.orelse) > 0
                })
            elif isinstance(child, ast.For):
                branches.append({
                    "type": "for",
                    "line": child.lineno,
                    "iterator": ast.unparse(child.iter) if hasattr(ast, 'unparse') else str(child.iter),
                    "has_else": len(child.orelse) > 0
                })
            elif isinstance(child, ast.While):
                branches.append({
                    "type": "while",
                    "line": child.lineno,
                    "condition": ast.unparse(child.test) if hasattr(ast, 'unparse') else str(child.test),
                    "has_else": len(child.orelse) > 0
                })
            elif isinstance(child, ast.Try):
                handlers = []
                for handler in child.handlers:
                    exc_type = self._get_node_name(handler.type) if handler.type else "Exception"
                    handlers.append(exc_type)
                branches.append({
                    "type": "try",
                    "line": child.lineno,
                    "handlers": handlers,
                    "has_else": len(child.orelse) > 0,
                    "has_finally": len(child.finalbody) > 0
                })
            elif isinstance(child, ast.Match):
                branches.append({
                    "type": "match",
                    "line": child.lineno,
                    "cases": len(child.cases)
                })
        
        return branches
    
    def _extract_raises(self, node: ast.AST) -> List[str]:
        """Extract all exception types that can be raised."""
        raises = set()
        for child in ast.walk(node):
            if isinstance(child, ast.Raise):
                if child.exc:
                    if isinstance(child.exc, ast.Call):
                        raises.add(self._get_node_name(child.exc.func))
                    elif isinstance(child.exc, ast.Name):
                        raises.add(child.exc.id)
        return list(raises)
    
    def _calculate_complexity(self, node: ast.AST) -> int:
        """Calculate cyclomatic complexity."""
        complexity = 1  # Base complexity
        
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
            elif isinstance(child, ast.comprehension):
                complexity += 1
                if child.ifs:
                    complexity += len(child.ifs)
        
        return complexity
    
    def _get_annotation_string(self, annotation: Optional[ast.AST]) -> Optional[str]:
        """Convert an annotation AST node to string."""
        if annotation is None:
            return None
        if hasattr(ast, 'unparse'):
            return ast.unparse(annotation)
        return self._get_node_name(annotation)
    
    def _get_node_name(self, node: ast.AST) -> str:
        """Get the name from an AST node."""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return f"{self._get_node_name(node.value)}.{node.attr}"
        elif isinstance(node, ast.Subscript):
            return f"{self._get_node_name(node.value)}[{self._get_node_name(node.slice)}]"
        elif isinstance(node, ast.Constant):
            return repr(node.value)
        elif isinstance(node, ast.Tuple):
            return ", ".join(self._get_node_name(elt) for elt in node.elts)
        elif hasattr(ast, 'unparse'):
            return ast.unparse(node)
        return str(node)
    
    def _get_decorator_name(self, decorator: ast.AST) -> str:
        """Get the name of a decorator."""
        if isinstance(decorator, ast.Name):
            return decorator.id
        elif isinstance(decorator, ast.Call):
            return self._get_node_name(decorator.func)
        elif isinstance(decorator, ast.Attribute):
            return f"{self._get_node_name(decorator.value)}.{decorator.attr}"
        return str(decorator)
    
    def _get_default_value(self, node: ast.AST) -> Any:
        """Get the default value from an AST node."""
        if isinstance(node, ast.Constant):
            return repr(node.value)
        elif isinstance(node, ast.List):
            return "[]"
        elif isinstance(node, ast.Dict):
            return "{}"
        elif isinstance(node, ast.Tuple):
            return "()"
        elif isinstance(node, ast.Set):
            return "set()"
        elif hasattr(ast, 'unparse'):
            return ast.unparse(node)
        return None


def analyze_file(filepath: str) -> ModuleInfo:
    """Convenience function to analyze a Python file."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {filepath}")
    
    source_code = path.read_text(encoding='utf-8')
    analyzer = ASTAnalyzer(source_code, filename=str(path))
    return analyzer.analyze()

