"""
Code Parser Module
==================

Parses Python source code and extracts structured information
for test generation purposes.
"""

from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from pathlib import Path
import re

from .ast_analyzer import ASTAnalyzer, ModuleInfo, FunctionInfo, ClassInfo


@dataclass
class TestableUnit:
    """Represents a unit of code that can be tested."""
    name: str
    qualified_name: str
    type: str  # 'function', 'method', 'class'
    source_code: str
    signature: str
    docstring: Optional[str]
    parameters: List[Dict[str, Any]]
    return_type: Optional[str]
    complexity: int
    branches: List[Dict[str, Any]]
    raises: List[str]
    dependencies: List[str]
    is_async: bool


class CodeParser:
    """
    Parses Python code and extracts testable units.
    
    Provides a higher-level interface for test generation,
    combining AST analysis with additional heuristics.
    """
    
    def __init__(self, source_code: str, filename: str = "<unknown>"):
        self.source_code = source_code
        self.filename = filename
        self.analyzer = ASTAnalyzer(source_code, filename)
        self._module_info: Optional[ModuleInfo] = None
    
    def parse(self) -> ModuleInfo:
        """Parse the source code and return module info."""
        self._module_info = self.analyzer.analyze()
        return self._module_info
    
    def get_testable_units(self) -> List[TestableUnit]:
        """Extract all testable units from the code."""
        if self._module_info is None:
            self.parse()
        
        units = []
        
        # Extract standalone functions
        for func in self._module_info.functions:
            if not func.name.startswith('_') or func.name.startswith('__'):
                units.append(self._create_testable_unit(func))
        
        # Extract class methods
        for cls in self._module_info.classes:
            for method in cls.methods:
                # Skip private methods except dunder methods
                if method.name.startswith('_') and not method.name.startswith('__'):
                    continue
                units.append(self._create_testable_unit(method, cls))
        
        return units
    
    def _create_testable_unit(
        self, 
        func: FunctionInfo, 
        cls: Optional[ClassInfo] = None
    ) -> TestableUnit:
        """Create a TestableUnit from function info."""
        if cls:
            qualified_name = f"{cls.name}.{func.name}"
            unit_type = "method"
        else:
            qualified_name = func.name
            unit_type = "function"
        
        # Build signature string
        signature = self._build_signature(func)
        
        # Extract dependencies from the function body
        dependencies = self._extract_dependencies(func)
        
        return TestableUnit(
            name=func.name,
            qualified_name=qualified_name,
            type=unit_type,
            source_code=func.source_code,
            signature=signature,
            docstring=func.docstring,
            parameters=func.args,
            return_type=func.returns,
            complexity=func.complexity,
            branches=func.branches,
            raises=func.raises,
            dependencies=dependencies,
            is_async=func.is_async
        )
    
    def _build_signature(self, func: FunctionInfo) -> str:
        """Build a function signature string."""
        params = []
        for arg in func.args:
            param_str = arg['name']
            if arg.get('type_hint'):
                param_str += f": {arg['type_hint']}"
            if arg.get('default') is not None:
                param_str += f" = {arg['default']}"
            params.append(param_str)
        
        async_prefix = "async " if func.is_async else ""
        return_annotation = f" -> {func.returns}" if func.returns else ""
        
        return f"{async_prefix}def {func.name}({', '.join(params)}){return_annotation}"
    
    def _extract_dependencies(self, func: FunctionInfo) -> List[str]:
        """Extract external dependencies used in the function."""
        # Simple heuristic: look for function calls in the source
        dependencies = []
        
        # Match function calls
        call_pattern = r'(\w+(?:\.\w+)*)\s*\('
        matches = re.findall(call_pattern, func.source_code)
        
        # Filter out common built-ins and self references
        builtins = {'print', 'len', 'range', 'str', 'int', 'float', 'list', 
                    'dict', 'set', 'tuple', 'bool', 'type', 'isinstance',
                    'hasattr', 'getattr', 'setattr', 'open', 'super', 'self'}
        
        for match in matches:
            if match not in builtins and not match.startswith('self.'):
                dependencies.append(match)
        
        return list(set(dependencies))
    
    def get_import_context(self) -> str:
        """Get the import statements needed for testing."""
        if self._module_info is None:
            self.parse()
        
        imports = []
        module_name = Path(self.filename).stem
        
        # Add imports from the module
        for imp in self._module_info.imports:
            imports.append(f"# Original import: {imp}")
        
        # Generate import for the module under test
        imports.append(f"from {module_name} import *")
        
        return "\n".join(imports)
    
    def get_class_info(self, class_name: str) -> Optional[ClassInfo]:
        """Get information about a specific class."""
        if self._module_info is None:
            self.parse()
        
        for cls in self._module_info.classes:
            if cls.name == class_name:
                return cls
        return None
    
    def get_function_info(self, func_name: str) -> Optional[FunctionInfo]:
        """Get information about a specific function."""
        if self._module_info is None:
            self.parse()
        
        for func in self._module_info.functions:
            if func.name == func_name:
                return func
        return None


def parse_file(filepath: str) -> CodeParser:
    """Convenience function to create a parser for a file."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {filepath}")
    
    source_code = path.read_text(encoding='utf-8')
    parser = CodeParser(source_code, filename=str(path))
    parser.parse()
    return parser

