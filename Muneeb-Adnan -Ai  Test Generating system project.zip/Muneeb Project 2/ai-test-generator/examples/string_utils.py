"""
String Utilities Module - Example Source File
==============================================

A sample module with various string manipulation functions
for demonstrating test generation capabilities.
"""

import re
from typing import List, Optional, Dict, Tuple


def reverse_string(s: str) -> str:
    """
    Reverse a string.
    
    Args:
        s: Input string
    
    Returns:
        Reversed string
    """
    return s[::-1]


def is_palindrome(s: str, ignore_case: bool = True, ignore_spaces: bool = True) -> bool:
    """
    Check if a string is a palindrome.
    
    Args:
        s: Input string
        ignore_case: Whether to ignore case
        ignore_spaces: Whether to ignore spaces
    
    Returns:
        True if the string is a palindrome
    """
    if ignore_case:
        s = s.lower()
    if ignore_spaces:
        s = s.replace(" ", "")
    
    return s == s[::-1]


def count_words(text: str) -> int:
    """
    Count the number of words in a text.
    
    Args:
        text: Input text
    
    Returns:
        Number of words
    """
    if not text or not text.strip():
        return 0
    return len(text.split())


def count_characters(text: str, include_spaces: bool = True) -> int:
    """
    Count characters in a text.
    
    Args:
        text: Input text
        include_spaces: Whether to include spaces in count
    
    Returns:
        Number of characters
    """
    if not include_spaces:
        text = text.replace(" ", "")
    return len(text)


def to_title_case(s: str) -> str:
    """
    Convert string to title case.
    
    Args:
        s: Input string
    
    Returns:
        Title-cased string
    """
    return s.title()


def to_snake_case(s: str) -> str:
    """
    Convert string to snake_case.
    
    Args:
        s: Input string (camelCase or PascalCase)
    
    Returns:
        snake_case string
    """
    # Insert underscore before uppercase letters
    result = re.sub(r'([A-Z])', r'_\1', s)
    # Remove leading underscore if present
    result = result.lstrip('_')
    # Convert to lowercase
    return result.lower()


def to_camel_case(s: str) -> str:
    """
    Convert string to camelCase.
    
    Args:
        s: Input string (snake_case or space-separated)
    
    Returns:
        camelCase string
    """
    # Split by underscore or space
    words = re.split(r'[_\s]+', s)
    
    if not words:
        return ""
    
    # First word lowercase, rest title case
    result = words[0].lower()
    for word in words[1:]:
        result += word.capitalize()
    
    return result


def truncate(s: str, max_length: int, suffix: str = "...") -> str:
    """
    Truncate a string to a maximum length.
    
    Args:
        s: Input string
        max_length: Maximum length (including suffix)
        suffix: Suffix to add if truncated
    
    Returns:
        Truncated string
    
    Raises:
        ValueError: If max_length is less than suffix length
    """
    if max_length < len(suffix):
        raise ValueError("max_length must be at least as long as suffix")
    
    if len(s) <= max_length:
        return s
    
    return s[:max_length - len(suffix)] + suffix


def extract_emails(text: str) -> List[str]:
    """
    Extract email addresses from text.
    
    Args:
        text: Input text
    
    Returns:
        List of email addresses found
    """
    pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    return re.findall(pattern, text)


def extract_urls(text: str) -> List[str]:
    """
    Extract URLs from text.
    
    Args:
        text: Input text
    
    Returns:
        List of URLs found
    """
    pattern = r'https?://[^\s<>"{}|\\^`\[\]]+'
    return re.findall(pattern, text)


def mask_email(email: str) -> str:
    """
    Mask an email address for privacy.
    
    Args:
        email: Email address to mask
    
    Returns:
        Masked email (e.g., "u***@example.com")
    """
    if '@' not in email:
        return email
    
    local, domain = email.split('@', 1)
    
    if len(local) <= 1:
        masked_local = local
    else:
        masked_local = local[0] + '*' * (len(local) - 1)
    
    return f"{masked_local}@{domain}"


def remove_html_tags(html: str) -> str:
    """
    Remove HTML tags from a string.
    
    Args:
        html: Input HTML string
    
    Returns:
        Plain text without HTML tags
    """
    clean = re.compile('<.*?>')
    return re.sub(clean, '', html)


def slugify(text: str) -> str:
    """
    Convert text to URL-friendly slug.
    
    Args:
        text: Input text
    
    Returns:
        URL-friendly slug
    """
    # Convert to lowercase
    slug = text.lower()
    
    # Replace spaces and special characters with hyphens
    slug = re.sub(r'[^\w\s-]', '', slug)
    slug = re.sub(r'[-\s]+', '-', slug)
    
    # Remove leading/trailing hyphens
    slug = slug.strip('-')
    
    return slug


def word_frequency(text: str) -> Dict[str, int]:
    """
    Count word frequencies in text.
    
    Args:
        text: Input text
    
    Returns:
        Dictionary of word frequencies
    """
    if not text:
        return {}
    
    # Normalize text
    text = text.lower()
    # Remove punctuation
    text = re.sub(r'[^\w\s]', '', text)
    
    words = text.split()
    frequency = {}
    
    for word in words:
        frequency[word] = frequency.get(word, 0) + 1
    
    return frequency


def find_longest_word(text: str) -> Optional[str]:
    """
    Find the longest word in text.
    
    Args:
        text: Input text
    
    Returns:
        The longest word, or None if no words
    """
    words = text.split()
    
    if not words:
        return None
    
    return max(words, key=len)


def wrap_text(text: str, width: int = 80) -> str:
    """
    Wrap text to a specified width.
    
    Args:
        text: Input text
        width: Maximum line width
    
    Returns:
        Wrapped text
    
    Raises:
        ValueError: If width is less than 1
    """
    if width < 1:
        raise ValueError("Width must be at least 1")
    
    words = text.split()
    lines = []
    current_line = []
    current_length = 0
    
    for word in words:
        word_length = len(word)
        
        if current_length + word_length + len(current_line) <= width:
            current_line.append(word)
            current_length += word_length
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
            current_length = word_length
    
    if current_line:
        lines.append(' '.join(current_line))
    
    return '\n'.join(lines)


class StringBuilder:
    """
    A mutable string builder class for efficient string concatenation.
    """
    
    def __init__(self, initial: str = ""):
        """Initialize with optional initial string."""
        self._parts: List[str] = [initial] if initial else []
    
    def append(self, s: str) -> 'StringBuilder':
        """Append a string."""
        self._parts.append(s)
        return self
    
    def append_line(self, s: str = "") -> 'StringBuilder':
        """Append a string with a newline."""
        self._parts.append(s + "\n")
        return self
    
    def prepend(self, s: str) -> 'StringBuilder':
        """Prepend a string."""
        self._parts.insert(0, s)
        return self
    
    def insert(self, index: int, s: str) -> 'StringBuilder':
        """Insert a string at index."""
        if index < 0:
            raise IndexError("Index cannot be negative")
        self._parts.insert(index, s)
        return self
    
    def clear(self) -> 'StringBuilder':
        """Clear all content."""
        self._parts.clear()
        return self
    
    def reverse(self) -> 'StringBuilder':
        """Reverse the content."""
        content = self.build()
        self._parts = [content[::-1]]
        return self
    
    def build(self) -> str:
        """Build the final string."""
        return ''.join(self._parts)
    
    def __str__(self) -> str:
        """Return the built string."""
        return self.build()
    
    def __len__(self) -> int:
        """Return the total length."""
        return sum(len(p) for p in self._parts)

