"""
Calculator Module - Example Source File
========================================

A sample Python module demonstrating various code patterns
for test generation.
"""

from typing import List, Optional, Union
from decimal import Decimal


class CalculatorError(Exception):
    """Custom exception for calculator errors."""
    pass


class DivisionByZeroError(CalculatorError):
    """Raised when attempting to divide by zero."""
    pass


class InvalidOperationError(CalculatorError):
    """Raised for invalid operations."""
    pass


def add(a: float, b: float) -> float:
    """
    Add two numbers.
    
    Args:
        a: First number
        b: Second number
    
    Returns:
        Sum of a and b
    """
    return a + b


def subtract(a: float, b: float) -> float:
    """
    Subtract b from a.
    
    Args:
        a: First number
        b: Second number
    
    Returns:
        Difference of a and b
    """
    return a - b


def multiply(a: float, b: float) -> float:
    """
    Multiply two numbers.
    
    Args:
        a: First number
        b: Second number
    
    Returns:
        Product of a and b
    """
    return a * b


def divide(a: float, b: float) -> float:
    """
    Divide a by b.
    
    Args:
        a: Dividend
        b: Divisor
    
    Returns:
        Quotient of a and b
    
    Raises:
        DivisionByZeroError: If b is zero
    """
    if b == 0:
        raise DivisionByZeroError("Cannot divide by zero")
    return a / b


def power(base: float, exponent: int) -> float:
    """
    Raise base to the power of exponent.
    
    Args:
        base: The base number
        exponent: The exponent
    
    Returns:
        base raised to exponent
    """
    return base ** exponent


def factorial(n: int) -> int:
    """
    Calculate factorial of n.
    
    Args:
        n: Non-negative integer
    
    Returns:
        Factorial of n
    
    Raises:
        ValueError: If n is negative
    """
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    if n == 0 or n == 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result


def fibonacci(n: int) -> int:
    """
    Calculate the nth Fibonacci number.
    
    Args:
        n: Position in Fibonacci sequence (0-indexed)
    
    Returns:
        The nth Fibonacci number
    
    Raises:
        ValueError: If n is negative
    """
    if n < 0:
        raise ValueError("Fibonacci is not defined for negative indices")
    if n <= 1:
        return n
    
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


def calculate_average(numbers: List[float]) -> float:
    """
    Calculate the average of a list of numbers.
    
    Args:
        numbers: List of numbers
    
    Returns:
        The arithmetic mean
    
    Raises:
        ValueError: If the list is empty
    """
    if not numbers:
        raise ValueError("Cannot calculate average of empty list")
    return sum(numbers) / len(numbers)


def calculate_median(numbers: List[float]) -> float:
    """
    Calculate the median of a list of numbers.
    
    Args:
        numbers: List of numbers
    
    Returns:
        The median value
    
    Raises:
        ValueError: If the list is empty
    """
    if not numbers:
        raise ValueError("Cannot calculate median of empty list")
    
    sorted_nums = sorted(numbers)
    n = len(sorted_nums)
    mid = n // 2
    
    if n % 2 == 0:
        return (sorted_nums[mid - 1] + sorted_nums[mid]) / 2
    else:
        return sorted_nums[mid]


def is_prime(n: int) -> bool:
    """
    Check if a number is prime.
    
    Args:
        n: Integer to check
    
    Returns:
        True if n is prime, False otherwise
    """
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    
    for i in range(3, int(n ** 0.5) + 1, 2):
        if n % i == 0:
            return False
    return True


def gcd(a: int, b: int) -> int:
    """
    Calculate the greatest common divisor.
    
    Args:
        a: First integer
        b: Second integer
    
    Returns:
        GCD of a and b
    """
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a


def lcm(a: int, b: int) -> int:
    """
    Calculate the least common multiple.
    
    Args:
        a: First integer
        b: Second integer
    
    Returns:
        LCM of a and b
    """
    if a == 0 or b == 0:
        return 0
    return abs(a * b) // gcd(a, b)


class Calculator:
    """
    A calculator class with memory and history features.
    """
    
    def __init__(self):
        """Initialize the calculator."""
        self.memory: float = 0.0
        self.history: List[str] = []
    
    def add(self, a: float, b: float) -> float:
        """Add two numbers and store in history."""
        result = a + b
        self._record_operation(f"{a} + {b} = {result}")
        return result
    
    def subtract(self, a: float, b: float) -> float:
        """Subtract two numbers and store in history."""
        result = a - b
        self._record_operation(f"{a} - {b} = {result}")
        return result
    
    def multiply(self, a: float, b: float) -> float:
        """Multiply two numbers and store in history."""
        result = a * b
        self._record_operation(f"{a} * {b} = {result}")
        return result
    
    def divide(self, a: float, b: float) -> float:
        """Divide two numbers and store in history."""
        if b == 0:
            raise DivisionByZeroError("Cannot divide by zero")
        result = a / b
        self._record_operation(f"{a} / {b} = {result}")
        return result
    
    def _record_operation(self, operation: str):
        """Record an operation in history."""
        self.history.append(operation)
    
    def store_in_memory(self, value: float):
        """Store a value in memory."""
        self.memory = value
    
    def recall_memory(self) -> float:
        """Recall the value from memory."""
        return self.memory
    
    def clear_memory(self):
        """Clear the memory."""
        self.memory = 0.0
    
    def get_history(self) -> List[str]:
        """Get operation history."""
        return self.history.copy()
    
    def clear_history(self):
        """Clear operation history."""
        self.history.clear()
    
    def evaluate(self, expression: str) -> float:
        """
        Evaluate a simple mathematical expression.
        
        Args:
            expression: A string like "2 + 3" or "10 / 2"
        
        Returns:
            The result of the expression
        
        Raises:
            InvalidOperationError: If the expression is invalid
        """
        expression = expression.strip()
        
        # Parse the expression
        operators = ['+', '-', '*', '/']
        operator = None
        
        for op in operators:
            if op in expression:
                parts = expression.split(op)
                if len(parts) == 2:
                    operator = op
                    break
        
        if operator is None:
            raise InvalidOperationError(f"Invalid expression: {expression}")
        
        try:
            a = float(parts[0].strip())
            b = float(parts[1].strip())
        except ValueError:
            raise InvalidOperationError(f"Invalid numbers in expression: {expression}")
        
        if operator == '+':
            return self.add(a, b)
        elif operator == '-':
            return self.subtract(a, b)
        elif operator == '*':
            return self.multiply(a, b)
        elif operator == '/':
            return self.divide(a, b)
        
        raise InvalidOperationError(f"Unknown operator: {operator}")

