"""
AI Test Generator - Web Interface
==================================

A Streamlit-based web frontend for the AI Test Generator.

Run with: streamlit run web_app.py
"""

import streamlit as st
import sys
from pathlib import Path
import tempfile
import os

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.analyzer.ast_analyzer import ASTAnalyzer
from src.analyzer.code_parser import CodeParser
from src.generator.test_generator import TestGenerator
from src.generator.llm_client import LLMProvider
from src.generator.edge_cases import EdgeCaseDetector
from src.executor.test_runner import TestRunner
from src.executor.coverage_analyzer import CoverageAnalyzer

# Page configuration
st.set_page_config(
    page_title="AI Test Generator",
    page_icon="🧪",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        text-align: center;
        color: #666;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
    }
    .success-box {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 5px;
        padding: 1rem;
        margin: 1rem 0;
    }
    .warning-box {
        background-color: #fff3cd;
        border: 1px solid #ffeeba;
        border-radius: 5px;
        padding: 1rem;
        margin: 1rem 0;
    }
    .stCodeBlock {
        max-height: 500px;
        overflow-y: auto;
    }
</style>
""", unsafe_allow_html=True)


def main():
    # Header
    st.markdown('<h1 class="main-header">🧪 AI Test Generator</h1>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Automatically generate comprehensive PyTest unit tests using AI</p>', unsafe_allow_html=True)
    
    # Sidebar configuration
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # LLM Provider selection
        provider = st.selectbox(
            "LLM Provider",
            ["Auto-detect", "Anthropic Claude", "OpenAI GPT-4", "Local (No API)"],
            help="Select the AI provider for test generation"
        )
        
        # API Key input
        if provider != "Local (No API)":
            api_key = st.text_input(
                "API Key (optional)",
                type="password",
                help="Enter your API key or set it as environment variable"
            )
        else:
            api_key = None
        
        # Target coverage
        target_coverage = st.slider(
            "Target Coverage %",
            min_value=50,
            max_value=100,
            value=90,
            help="Minimum code coverage to achieve"
        )
        
        # Options
        st.subheader("Options")
        include_edge_cases = st.checkbox("Include Edge Cases", value=True)
        include_docstrings = st.checkbox("Include Docstrings", value=True)
        parametrized_tests = st.checkbox("Use Parametrized Tests", value=True)
        
        st.divider()
        
        # Info
        st.info("""
        **How to use:**
        1. Paste your Python code or upload a file
        2. Click "Analyze Code" to see structure
        3. Click "Generate Tests" to create tests
        4. Download the generated tests
        """)
    
    # Main content area with tabs
    tab1, tab2, tab3, tab4 = st.tabs(["📝 Code Input", "🔍 Analysis", "🧪 Generated Tests", "📊 Coverage"])
    
    # Initialize session state
    if 'source_code' not in st.session_state:
        st.session_state.source_code = ""
    if 'analysis_result' not in st.session_state:
        st.session_state.analysis_result = None
    if 'generated_tests' not in st.session_state:
        st.session_state.generated_tests = None
    
    # Tab 1: Code Input
    with tab1:
        st.subheader("Enter Your Python Code")
        
        # File upload or text input
        input_method = st.radio(
            "Input Method",
            ["Paste Code", "Upload File"],
            horizontal=True
        )
        
        if input_method == "Upload File":
            uploaded_file = st.file_uploader(
                "Upload Python file",
                type=['py'],
                help="Upload a .py file to analyze"
            )
            if uploaded_file:
                st.session_state.source_code = uploaded_file.read().decode('utf-8')
                st.success(f"Loaded: {uploaded_file.name}")
        
        # Code editor
        source_code = st.text_area(
            "Python Source Code",
            value=st.session_state.source_code,
            height=400,
            placeholder='''# Paste your Python code here
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
''',
            help="Enter the Python code you want to generate tests for"
        )
        
        st.session_state.source_code = source_code
        
        # Example code buttons
        st.subheader("Or try an example:")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("📐 Calculator Example"):
                st.session_state.source_code = '''def add(a: float, b: float) -> float:
    """Add two numbers."""
    return a + b

def subtract(a: float, b: float) -> float:
    """Subtract b from a."""
    return a - b

def multiply(a: float, b: float) -> float:
    """Multiply two numbers."""
    return a * b

def divide(a: float, b: float) -> float:
    """Divide a by b."""
    if b == 0:
        raise ZeroDivisionError("Cannot divide by zero")
    return a / b

def factorial(n: int) -> int:
    """Calculate factorial of n."""
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    if n == 0 or n == 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result
'''
                st.rerun()
        
        with col2:
            if st.button("📝 String Utils Example"):
                st.session_state.source_code = '''def reverse_string(s: str) -> str:
    """Reverse a string."""
    return s[::-1]

def is_palindrome(s: str) -> bool:
    """Check if a string is a palindrome."""
    s = s.lower().replace(" ", "")
    return s == s[::-1]

def count_words(text: str) -> int:
    """Count words in text."""
    if not text or not text.strip():
        return 0
    return len(text.split())

def truncate(s: str, max_length: int, suffix: str = "...") -> str:
    """Truncate string to max length."""
    if max_length < len(suffix):
        raise ValueError("max_length must be >= suffix length")
    if len(s) <= max_length:
        return s
    return s[:max_length - len(suffix)] + suffix
'''
                st.rerun()
        
        with col3:
            if st.button("🏗️ Class Example"):
                st.session_state.source_code = '''class BankAccount:
    """A simple bank account class."""
    
    def __init__(self, owner: str, balance: float = 0.0):
        self.owner = owner
        self.balance = balance
        self.transactions = []
    
    def deposit(self, amount: float) -> float:
        """Deposit money into the account."""
        if amount <= 0:
            raise ValueError("Deposit amount must be positive")
        self.balance += amount
        self.transactions.append(f"Deposit: +{amount}")
        return self.balance
    
    def withdraw(self, amount: float) -> float:
        """Withdraw money from the account."""
        if amount <= 0:
            raise ValueError("Withdrawal amount must be positive")
        if amount > self.balance:
            raise ValueError("Insufficient funds")
        self.balance -= amount
        self.transactions.append(f"Withdrawal: -{amount}")
        return self.balance
    
    def get_balance(self) -> float:
        """Get current balance."""
        return self.balance
    
    def get_statement(self) -> str:
        """Get account statement."""
        return f"Account: {self.owner}\\nBalance: ${self.balance:.2f}"
'''
                st.rerun()
    
    # Tab 2: Analysis
    with tab2:
        st.subheader("Code Analysis")
        
        if st.button("🔍 Analyze Code", type="primary", use_container_width=True):
            if st.session_state.source_code.strip():
                with st.spinner("Analyzing code structure..."):
                    try:
                        parser = CodeParser(st.session_state.source_code, "input.py")
                        module_info = parser.parse()
                        testable_units = parser.get_testable_units()
                        
                        st.session_state.analysis_result = {
                            'module_info': module_info,
                            'testable_units': testable_units
                        }
                        
                        st.success("✅ Analysis complete!")
                    except Exception as e:
                        st.error(f"❌ Analysis failed: {str(e)}")
            else:
                st.warning("Please enter some Python code first!")
        
        if st.session_state.analysis_result:
            result = st.session_state.analysis_result
            module_info = result['module_info']
            testable_units = result['testable_units']
            
            # Metrics
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Functions", len(module_info.functions))
            with col2:
                st.metric("Classes", len(module_info.classes))
            with col3:
                st.metric("Testable Units", len(testable_units))
            with col4:
                total_complexity = sum(f.complexity for f in module_info.functions)
                total_complexity += sum(m.complexity for c in module_info.classes for m in c.methods)
                st.metric("Total Complexity", total_complexity)
            
            st.divider()
            
            # Functions detail
            if module_info.functions:
                st.subheader("📦 Functions")
                for func in module_info.functions:
                    with st.expander(f"**{func.name}** (complexity: {func.complexity})"):
                        st.code(func.source_code, language="python")
                        
                        if func.docstring:
                            st.info(f"📝 {func.docstring}")
                        
                        if func.args:
                            st.write("**Parameters:**")
                            for arg in func.args:
                                type_hint = f": {arg.get('type_hint', 'Any')}" if arg.get('type_hint') else ""
                                default = f" = {arg.get('default')}" if arg.get('default') else ""
                                st.write(f"  - `{arg['name']}{type_hint}{default}`")
                        
                        if func.returns:
                            st.write(f"**Returns:** `{func.returns}`")
                        
                        if func.raises:
                            st.write(f"**Raises:** {', '.join(func.raises)}")
            
            # Classes detail
            if module_info.classes:
                st.subheader("🏗️ Classes")
                for cls in module_info.classes:
                    with st.expander(f"**{cls.name}** ({len(cls.methods)} methods)"):
                        if cls.docstring:
                            st.info(f"📝 {cls.docstring}")
                        
                        st.write("**Methods:**")
                        for method in cls.methods:
                            st.write(f"  - `{method.name}()` (complexity: {method.complexity})")
            
            # Edge cases preview
            st.subheader("🎯 Detected Edge Cases")
            detector = EdgeCaseDetector()
            
            for unit in testable_units[:3]:  # Show first 3 units
                edge_cases = detector.detect_edge_cases(
                    parameters=unit.parameters,
                    return_type=unit.return_type,
                    raises=unit.raises,
                    source_code=unit.source_code
                )
                
                if edge_cases:
                    with st.expander(f"Edge cases for **{unit.qualified_name}**"):
                        for ec in edge_cases[:5]:
                            st.write(f"  • {ec.description}")
    
    # Tab 3: Generated Tests
    with tab3:
        st.subheader("Generate Tests")
        
        if st.button("🧪 Generate Tests", type="primary", use_container_width=True):
            if st.session_state.source_code.strip():
                # Map provider selection
                provider_map = {
                    "Auto-detect": None,
                    "Anthropic Claude": LLMProvider.ANTHROPIC,
                    "OpenAI GPT-4": LLMProvider.OPENAI,
                    "Local (No API)": LLMProvider.LOCAL
                }
                
                with st.spinner("🤖 Generating tests with AI... This may take a moment."):
                    try:
                        # Create temp file for source
                        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
                            f.write(st.session_state.source_code)
                            temp_source = f.name
                        
                        # Create temp dir for output
                        temp_output = tempfile.mkdtemp()
                        
                        # Initialize generator
                        generator = TestGenerator(
                            llm_provider=provider_map.get(provider),
                            api_key=api_key if api_key else None
                        )
                        
                        # Generate tests
                        result = generator.generate_tests(
                            source_file=temp_source,
                            output_dir=temp_output,
                            min_coverage=target_coverage
                        )
                        
                        if result.get('success'):
                            # Read generated test file
                            test_file_path = Path(result['test_file'])
                            generated_code = test_file_path.read_text(encoding='utf-8')
                            
                            st.session_state.generated_tests = generated_code
                            st.success(f"✅ Generated {result['tests_generated']} test(s) using {result['provider']}!")
                        else:
                            st.error(f"❌ Generation failed: {result.get('message', 'Unknown error')}")
                        
                        # Cleanup
                        os.unlink(temp_source)
                    
                    except Exception as e:
                        st.error(f"❌ Error generating tests: {str(e)}")
                        import traceback
                        st.code(traceback.format_exc())
            else:
                st.warning("Please enter some Python code first!")
        
        if st.session_state.generated_tests:
            st.subheader("Generated Test Code")
            
            # Display generated tests
            st.code(st.session_state.generated_tests, language="python")
            
            # Download button
            st.download_button(
                label="📥 Download Tests",
                data=st.session_state.generated_tests,
                file_name="test_generated.py",
                mime="text/x-python",
                use_container_width=True
            )
            
            # Copy to clipboard info
            st.info("💡 Tip: Save this file as `test_<your_module>.py` in your tests directory and run with `pytest`")
    
    # Tab 4: Coverage
    with tab4:
        st.subheader("Coverage Analysis")
        
        st.info("""
        **To measure coverage:**
        1. Save your source code and generated tests
        2. Run: `pytest --cov=your_module test_your_module.py`
        3. View the coverage report
        """)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            ### 📊 Coverage Commands
            
            ```bash
            # Run tests with coverage
            pytest --cov=. --cov-report=term-missing
            
            # Generate HTML report
            pytest --cov=. --cov-report=html
            
            # Check coverage threshold
            pytest --cov=. --cov-fail-under=90
            ```
            """)
        
        with col2:
            st.markdown(f"""
            ### 🎯 Target Coverage
            
            **Target: {target_coverage}%**
            
            The AI will attempt to generate tests that cover:
            - ✅ All function branches
            - ✅ Edge cases (null, empty, boundary)
            - ✅ Exception handling paths
            - ✅ Normal execution flows
            """)
        
        # Coverage meter visualization
        st.subheader("Coverage Target")
        st.progress(target_coverage / 100)
        st.caption(f"Target: {target_coverage}% code coverage")
    
    # Footer
    st.divider()
    st.markdown("""
    <div style="text-align: center; color: #888;">
        <p>Built with ❤️ using Streamlit | AI Test Generator v1.0.0</p>
        <p>Supports Python 3.9+ | PyTest | Coverage.py</p>
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()

